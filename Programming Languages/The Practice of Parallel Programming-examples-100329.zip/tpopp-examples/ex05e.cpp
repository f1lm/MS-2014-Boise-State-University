#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>


void ex05ea()
{
	int s;
	sockaddr_in server;
// [[ex05ea]]
connect(s, (sockaddr *)&server, sizeof(server));
close(s);
// END
}

void ex05eb()
{
	int s;
	sockaddr_in server;
// [[ex05eb]]
char zero = 0;
connect(s, (sockaddr *)&server, sizeof(server));
write(s, &zero, 1);
close(s);
// END
}
