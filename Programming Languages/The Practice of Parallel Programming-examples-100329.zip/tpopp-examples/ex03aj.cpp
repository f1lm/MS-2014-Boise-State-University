#include "pwext.hpp"
#include <list>
#include <algorithm>
#include <stdio.h>
#include <unistd.h>

namespace pw {

// [[ex03aj]]
// DEBUG descr Condition variable implementation using an event, the correct version.
class condvar
{
public:
	condvar()
	{ }

	// m is locked on both entry and exit
	int wait(pw::pmutex *m)
	{
		event ev(false); // a private unsignaled event
		evlist_.push_back(&ev);
		{
			pw::unlockmutex ul(*m);
			ev.wait();
		}
		return 0;
	}
	// m is locked on both entry and exit
	int timedwait(pw::pmutex *m, 
		const struct timespec &abstime)
	{
		event ev(false); // a private unsignaled event
		evlist_.push_back(&ev);
		int res;
		{
			pw::unlockmutex ul(*m);
			res = ev.timedwait(abstime);
		}
		if (res == ETIMEDOUT) {
			eventlist::iterator it = find(evlist_.begin(), 
				evlist_.end(), &ev);
			if (it != evlist_.end()) {
				evlist_.erase(it);
				return ETIMEDOUT;
			}
			// otherwise it got signaled while locking back
			// the mutex
		} return 0; }
	// the caller must have the same mutex as used in
	// wait() locked; unlike POSIX, this is a mandatory
	// requirement
	int broadcast()
	{
		while (!evlist_.empty()) {
			evlist_.front()->signal();
			evlist_.pop_front();
		}
		return 0;
	}
	// the caller must have the same mutex as used in
	// wait() locked; unlike POSIX, this is a mandatory
	// requirement
	int signal()
	{
		if (!evlist_.empty()) {
			evlist_.front()->signal();
			evlist_.pop_front();
		}
		return 0;
	}

protected:
	typedef std::list<event *> eventlist;
	eventlist evlist_;
};
// END

};

// DEBUG {
pw::pmutex mtx;
pw::condvar cv;
int flag;

class waiter : public pw::pwthread
{
public:
	// auto-start on construction and stop before destruction
	waiter()
	{
		start();
	}
	~waiter()
	{
		join();
	}
	void *execute()
	{
		mtx.lock();
		while (flag == 0) {
			cv.wait(&mtx);
		}
		--flag;
		mtx.unlock();
		fprintf(stderr, "wait succeeded\n");
		return 0;
	}
};

int main()
{
	mtx.lock();
	cv.broadcast();

	struct timespec endtime;
	clock_gettime(CLOCK_REALTIME, &endtime); // the current time
	if (cv.timedwait(&mtx, endtime) == ETIMEDOUT)
		fprintf(stderr, "timedwait failed as expected\n");
	mtx.unlock();

	{
		waiter w1, w2, w3;
		usleep(100*1000);
		mtx.lock();
		flag += 3;
		cv.broadcast();
		mtx.unlock();
	}
	{
		waiter w1, w2, w3;
		usleep(100*1000);
		mtx.lock();
		flag += 3;
		cv.signal();
		cv.signal();
		cv.signal();
		mtx.unlock();
	}
	return 0;
}
// DEBUG }
/* Sample output:

timedwait failed as expected
wait succeeded
wait succeeded
wait succeeded
wait succeeded
wait succeeded
wait succeeded

*/
