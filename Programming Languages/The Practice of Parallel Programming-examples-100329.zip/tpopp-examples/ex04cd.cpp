#include "ptwrap.hpp"
#include <deque>
#include <stdio.h>
#include <assert.h>

struct Message 
{
	virtual ~Message() { } // allow for polymorphism

	enum {
		EXIT,
		NORMAL // first normal type
	};
	int msgtype_;
	// ... whatever else is needed by the application ...
};

class Queue 
{
	// DEBUG {
public:
	enum {
		DEFAULT_LIMIT = 1000
	};

	Queue(int limit = DEFAULT_LIMIT) :
		limit_(limit), 
		dqwr_(&deque1_), dqrd_(&deque2_), condrd_(condwr_)
	{ }

	virtual ~Queue()
	{ 
		Message *m;
		while (!deque1_.empty()) {
			m = deque1_.front();
			deque1_.pop_front();
			delete m;
		}
		while (!deque2_.empty()) {
			m = deque2_.front();
			deque2_.pop_front();
			delete m;
		}
	}

	// this combines the STL front() and pop_front() since
	// the popping must be atomic;
	// the receiver takes over the ownership of the message
	Message *pop_front()
	{
		pw::lockmutex lm(mutexrd_);

		while(dqrd_->empty()) {
			pw::lockmutex lm(condwr_);

			if (dqwr_->empty()) {
				condrd_.wait(); // it releases and gets back the mutex
			} else {
				swap(dqwr_, dqrd_);
				// if the write buffer was full, wake up the writers
				condwr_.broadcast();
			}
		}

		Message *m = dqrd_->front();
		dqrd_->pop_front();
		return m;
	}

	// takes over the ownership of the message;
	// returns true if the message was posted, false if discarded
	virtual bool post(Message *m)
	{
		push_back(m); // the default implementation
		return true;
	}

protected:
	int limit_;
	std::deque<Message *> deque1_, deque2_;
	pw::pmutex mutexrd_;
	std::deque<Message *> *dqwr_, *dqrd_;
	pw::pmcond condwr_;
	pw::pchaincond condrd_;
	// DEBUG }
	// ...
protected:
	// Caller must have the mutex in condwr_ locked.
	void push_back_l(Message *m)
	{
		while (dqwr_->size() >= limit_)
			condwr_.wait(); // it releases and gets back the mutex

		dqwr_->push_back(m);
		condrd_.broadcast();
	}
	void push_back(Message *m)
	{
		pw::lockmutex lm(condwr_);
		push_back_l(m);
	}
	// ...
};

// [[ex04cd]]
// DEBUG descr A queue subclass that stops on EXIT messages collected from all the writers.
class AllExitQueue : public Queue
{
public:
	AllExitQueue(int limit = DEFAULT_LIMIT) : 
		Queue (limit),
		exitposted_(false), nwriters_(0)
	{ }

	// virtual in case if later a subclass wants to do
	// something different; returns true on success,
	// or false if the handler has already been told
	// to exit
	virtual bool add_writer()
	{ 
		pw::lockmutex lm(mutexx_);
		if (exitposted_)
			return false;
		++nwriters_;
		return true;
	}

	virtual bool post(Message *m)
	{
		pw::lockmutex lm(mutexx_);
		if (exitposted_) {
			delete m;
			return false;
		}
		if (m->msgtype_ == Message::EXIT) {
			if (--nwriters_ <= 0) {
				// last writer, post EXIT to the handler
				exitposted_ = true;
			} else {
				// message is processed successfully but it
				// has nothing to pass to the handler yet
				delete m;
				return true;
			}
		}
		push_back(m);
		return true;
	}

protected:
	// for the exit accounting
	pw::pmutex mutexx_; 
	// whether the EXIT message was posted to the queue
	bool exitposted_; 
	// number of writers that haven't already exited
	int nwriters_; 
};
// END

// DEBUG {
struct data : public Message
{
	int v_;

	data(int v, int kind = NORMAL) : v_(v)
	{ 
		Message::msgtype_ = kind;
	}
	~data()
	{
		fprintf(stderr, "deleted data %d\n", v_);
	}
};

int main()
{
	AllExitQueue q;
	q.add_writer();
	q.post(new data(1));
	q.post(new data(2));
	data * v2 = static_cast<data *>(q.pop_front());
	assert(v2->v_ == 1);
	delete v2;
	return 0;
}
/* Sample output:
deleted data 1
deleted data 2
*/
// DEBUG }
