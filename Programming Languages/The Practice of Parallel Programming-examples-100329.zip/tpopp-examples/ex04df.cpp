#include "ptwrap.hpp"
#include <deque>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

struct Message 
{
	Message(int mtype) : msgtype_(mtype)
	{ }
	virtual ~Message() { } // allow for polymorphism

	enum {
		EXIT,
		CANCEL,
		NORMAL, // first normal type
		SOME_MSG_1
	};
	int msgtype_;
	// ... whatever else is needed by the application ...
};

class SomeMessage : public Message
{
public:
	SomeMessage(int mtype) : Message(mtype)
	{ }
	virtual int getData()
	{
		return -1;
	}
	enum {
		URGENT_MSG_1 = NORMAL, // start after the base-class msg types
		URGENT_MSG_2,
		SOME_NORMAL,
		SOME_TYPE
	};
};

class Queue
{
public:
	Message *pop_front()
	{
		return 0;
	}
	void post(Message *m)
	{
	}
};

// [[ex04df]]
// DEBUG descr An attempt to modify the handler state synchronously causes a race condition.
class SomeHandler : public pw::pwthread
{
public:
	// ...
	void *execute()
	{
		while(true) {
			SomeMessage *m = (SomeMessage *)q_->pop_front();
			{
				pw::lockmutex lm(mutex_);

				switch (m->msgtype_) {
				case Message::EXIT:
					nextq_->post(m);
					return 0;
				case Message::CANCEL:
					nextq_->post(m);
					break;
				case SomeMessage::SOME_NORMAL:
					// ... process it ...
					delete m;
					break;
				}
			}
		}
		return 0;
	}
	// ...
	// DEBUG {
	Queue *q_, *nextq_;
	pw::pmutex mutex_;
	// DEBUG }
};
// END
