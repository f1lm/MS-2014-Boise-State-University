#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "ptwrap.hpp"

// [[ex02fa]]
// DEBUG descr Avoidance of the recursive mutexes.
class MyClass 
{
public:
	void foo() 
	{
		pw::lockmutex lm(mutex_);
		// ...
		bar_l();
		// ...
		bar_l();
		// ...
	}
	void bar() 
	{
		pw::lockmutex lm(mutex_);
		bar_l();
	}

protected:
	void bar_l()
	{
		// ...
	}

	pw::pmutex mutex_;
};
// END

