#include "pwext.hpp"
#include <stdio.h>
#include <unistd.h>
#include <errno.h>

struct Request
{
	bool isValid()
	{
		return false;
	}
	void handle()
	{ }
};

pw::semaphore started(0);

// copied from ex05da, with debugging printout
class worker : public pw::pwthread
{
public:
	worker(int fd) : 
		exit_flag_(false), exit_confirm_flag_(false), fd_(fd)
	{ }
	// ...
	void *execute()
	{
		while(!get_exit_flag()) {
			struct Request r;
			int fd;

			if (get_exit_flag())
				break;

			{
				pw::lockmutex lm(fd_mutex_);
				fd = fd_;
				if (fd < 0)
					break;
			}
			fprintf(stderr, "worker thread in the loop\n");
			started.signal();
			// usleep(10*1000); // artificially increase the race window
			// fprintf(stderr, "worker thread is about to read the request\n");
			int len = ::read(fd, (char *)&r, sizeof r);
			if (len != sizeof r)
				break;

			if (get_exit_flag())
				break;
			if (!r.isValid())
				continue;

			// ... handle the request...
		}
		{
			pw::lockmutex lm(fd_mutex_);
			if (fd_ >= 0)
				close(fd_);
		}
		{
			pw::lockmutex lm(exit_mutex_);
			exit_confirm_flag_ = true;
		}
		exit_confirm_event_.signal();
	}

	// DEBUG to
// [[ex05db]]
// DEBUG descr A timeout reduces the chances of a race on close.
	void stop()
	{
		{
			pw::lockmutex lm(exit_mutex_);
			exit_flag_ = true;
		}
		exit_event_.signal();
		{
			pw::lockmutex lm(fd_mutex_);
			if (fd_ >= 0) {
				int fd = fd_;
				fd_ = -1;
				usleep(10*1000); // 10ms = 10000 mcs
				close(fd);
	// DEBUG {
				fprintf(stderr, "closed fd %d\n", fd);
	// DEBUG }
			}
		}
	}
// END
	// DEBUG from

protected:
	bool get_exit_flag()
	{
		pw::lockmutex lm(exit_mutex_);
		return exit_flag_;
	}

	bool exit_flag_;
	bool exit_confirm_flag_;
	pw::pmutex exit_mutex_;
	pw::event exit_event_;
	pw::event exit_confirm_event_;
	// ...
	int fd_; // file descriptor to read the requests from
	pw::pmutex fd_mutex_;
};

// DEBUG {
int main(int argc, char **argv)
{
	worker w(0);
	w.start();
	started.wait();
	w.stop();
	w.join();
}
// DEBUG }

/* Sample output:
worker thread in the loop
*/
