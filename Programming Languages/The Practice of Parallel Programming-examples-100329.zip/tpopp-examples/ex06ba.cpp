typedef int word;

// [[ex06ba]]
// DEBUG descr The atomic CompareAndSwap operation.
bool CompareAndSwap(word *target, 
	word oldval, word newval)
{
	if (*target != oldval)
		return false;
	*target = newval;
	return true;
}
// END
