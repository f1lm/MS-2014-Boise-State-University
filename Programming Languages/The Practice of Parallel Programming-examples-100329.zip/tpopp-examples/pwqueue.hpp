#ifndef __pwqueue_hpp__
#define __pwqueue_hpp__
#include <deque>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include "pwext.hpp"

#define EX04_NESTED
namespace pw {
#include "ex04dc.cpp"
};
#undef EX04_NESTED

#endif // __pwqueue_hpp__
