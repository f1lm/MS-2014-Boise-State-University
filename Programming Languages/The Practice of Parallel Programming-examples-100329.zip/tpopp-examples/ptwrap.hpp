#ifndef __ptwrap_hpp__
#define __ptwrap_hpp__
#include "ex01.cpp"
#endif // __ptwrap_hpp__
