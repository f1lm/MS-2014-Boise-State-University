#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "ptwrap.hpp"

class Buffer
{
public:
	bool full()
	{
		return true;
	}
	bool append(char *data)
	{
		delete [] data;
	}
};

class Example {
public:
	Buffer buffer;
	char *read()
	{
		return 0;
	}

	pw::pmutex mutex;

void ex02da()
// [[ex02da]]
// DEBUG descr Appending data to a buffer, synchronization with a scope unlock.
{
	pw::lockmutex lm(mutex);

	while(!buffer.full()) {
		char *data = 0; // gets allocated dynamically
		{
			pw::unlockmutex um(mutex);

			data = read();
		}
		if (data)
			buffer.append(data); // consumes the dynamic data
	}
}
// END
};
