void *LoadLinked(void **target);
bool StoreConditional(void **target, void *newval);

// copied from ex06bc
class stack 
{
public: 
	struct node {
		node * volatile next_;
		int payload_; // the payload may be of any type
	};

	stack() : head_(0)
	{ }

	~stack()
	{
		while (pop() != 0) { }
	}
	// DEBUG to
// [[ex06bd]]
// DEBUG descr LoadLinked/StoreConditional operations improve the lock-free stack.
	void push(node *n)
	{
		do {
			n->next_ = (node *)LoadLinked((void **)&head_);
		} while ( !StoreConditional((void **)&head_, n) );
	}

	node *pop()
	{
		volatile node *top;
		do {
			top = (node *)LoadLinked((void **)&head_);
			if (top == 0)
				return 0;
		} while ( !StoreConditional(
				(void **)&head_, top->next_) );
		return (node *)top;
	}
// END
	// DEBUG from
protected:
	// the head of the list, representing the top of stack
	node * volatile head_;
};
