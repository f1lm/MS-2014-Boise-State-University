#include <stdio.h>
#include <string>

// [[ex05gb]]
// DEBUG descr The singleton replaced with the explicit object reference passing.
class logger
{
public:
	logger(const std::string &path);
	~logger();
	void log(const std::string &s);
};

//... somewhere in the code

class bar
{
public:
	bar(logger *log); // sets log_

	void do_bar(int x)
	{
		// ...
		log_->log(
			"error: bad parameters to method bar::bar()");
		// ...
	}

protected:
	logger *log_;
};

class foo
{
public:
	foo(logger *log); // sets log_

	void do_foo(int a, int b)
	{
		// ...
		log_->log(
			"error: bad parameters to method foo::foo()");
		// ...
		bar mybar(log_);
		mybar.do_bar(b);
		// ...
	}

protected:
	logger *log_;
};

void baz(logger *log, int x)
{
	// ...
	log->log(
		"error: bad parameters to function baz()");
	// ...
}

int main(int argc, char **argv)
{
	logger *log = new logger(argc > 1? 
		argv[1] : "/tmp/log");
	// ...
	foo myfoo(log);
	// ...
	myfoo.do_foo(1, 2);
	baz(log, 3);
	// ...
	delete log;
	return 0;
}
// END

// DEBUG {
void logger::log(const std::string &s)
{
	fprintf(stderr, "%s\n", s.c_str());
}
logger::logger(const std::string &path)
{
	fprintf(stderr, 
		"logger instance created and opened\n");
}
logger::~logger()
{
	fprintf(stderr, "logger instance destroyed\n");
}

foo::foo(logger *log) :
	log_(log)
{ }
bar::bar(logger *log) :
	log_(log)
{ }
// DEBUG }

/* Sample output:
logger instance created and opened
error: bad parameters to method foo::foo()
error: bad parameters to method bar::bar()
error: bad parameters to function baz()
logger instance destroyed

*/
