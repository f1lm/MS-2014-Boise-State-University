#include "ptwrap.hpp"

class Object {
public:
	Object(const char *s)
	{ }
	void do_something()
	{ }
};

// [[ex02fd]]
void function()
{
	static pw::pmutex m;
	m.lock();
	static Object obj("abcd");
	m.unlock();

	obj.do_something();
}
// END
