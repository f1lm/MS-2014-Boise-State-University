#include "pwext.hpp"

void ex03ea()
{
	int n_mutexes = 1;
	pw::pmutex mutexes[1];
	int i;

// [[ex03ea]]
for (i = 0; i < n_mutexes; i++)
	mutexes[i].lock();
// END
}

void ex03eb()
{
	int n_mutexes = 1;
	class smutex : public pw::pmutex
	{
	public:
		void request_lock()
		{ }
		void wait_lock()
		{ }
	};
	smutex mutexes[1];
	int i;

// [[ex03eb]]
for (i = 0; i < n_mutexes; i++)
	mutexes[i].request_lock();
for (i = 0; i < n_mutexes; i++)
	mutexes[i].wait_lock();
// END
}
