// REQUIRS PTYPES SO NOT MORMALLY BUILT
#include <pasync.h>

struct header
{
	int sequence;
};

void ex06bb(header *packet)
{
// [[ex06bb]]
static int sequence = 0;
// ...
packet->sequence = pt::pincrement(&sequence);
// END
}
