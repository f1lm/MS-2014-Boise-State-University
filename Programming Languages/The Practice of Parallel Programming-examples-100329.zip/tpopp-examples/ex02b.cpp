#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "ptwrap.hpp"

pw::pmutex mutex;

bool call()
{
	return false;
};

bool doit()
{
// DEBUG start of examples

// [[ex02ba]]
mutex.lock();
call();
mutex.unlock();
// END

// [[ex02bb]]
mutex.lock();
if (!call()) {
	mutex.unlock();
	return false;
}
mutex.unlock();
// END

// [[ex02bc]]
bool ok;
mutex.lock();
ok = call();
mutex.unlock();
if (!ok)
	return false;
// END

// [[ex02bd]]
mutex.lock();
try {
	call();
} catch(...) {
	mutex.unlock();
	throw;
}
mutex.unlock();
// END


// DEBUG end of examples
return 0;
}

int main()
{
	doit();
	return 0;
}

