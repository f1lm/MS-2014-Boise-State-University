#include "pwext.hpp"
#include <stdio.h>
#include <unistd.h>

namespace pw {

// [[ex03ah]]
// DEBUG descr Condition variable implementation using an event, the first attempt.
class condvar
{
public:
	condvar() :
		seq_(0),
		seqsig_(0)
	{ }

	// m is locked on both entry and exit
	int wait(pw::pmutex *m)
	{
		unsigned s = ++seq_;
		while (true) {
			ev_.reset();
			{
				pw::unlockmutex ul(*m);
				ev_.wait();
			}
			if (seqsig_ - s >= 0)
				return 0;
		}
	}
	// m is locked on both entry and exit
	int timedwait(pw::pmutex *m, 
		const struct timespec &abstime)
	{
		unsigned s = ++seq_;
		while (true) {
			ev_.reset();
			{
				pw::unlockmutex ul(*m);
				if (ev_.timedwait(abstime) == ETIMEDOUT) 
					return ETIMEDOUT;
			}
			if (seqsig_ - s >= 0)
				return 0;
		}
	}
	// the caller must have the same mutex as used in
	// wait() locked; unlike POSIX, this is a mandatory
	// requirement, though the assignment _might_ work OK
	// anyway even without the mutex held
	int broadcast()
	{
		seqsig_ = seq_;
		ev_.signal();
		return 0;
	}

protected:
	event ev_;
	// every wait increases the sequence
	unsigned seq_; 
	// broadcast frees all the waits up to this sequence
	unsigned seqsig_; 
};
// END

};

// DEBUG {
pw::pmutex mtx;
pw::condvar cv;
int flag;

class waiter : public pw::pwthread
{
public:
	// auto-start on construction and stop before destruction
	waiter()
	{
		start();
	}
	~waiter()
	{
		join();
	}
	void *execute()
	{
		mtx.lock();
		while (flag == 0) {
			cv.wait(&mtx);
		}
		--flag;
		mtx.unlock();
		fprintf(stderr, "wait succeeded\n");
		return 0;
	}
};

int main()
{
	mtx.lock();
	cv.broadcast();

	struct timespec endtime;
	clock_gettime(CLOCK_REALTIME, &endtime); // the current time
	if (cv.timedwait(&mtx, endtime) == ETIMEDOUT)
		fprintf(stderr, "timedwait failed as expected\n");
	mtx.unlock();

	{
		waiter w1, w2, w3;
		usleep(100*1000);
		mtx.lock();
		flag += 3;
		cv.broadcast();
		mtx.unlock();
	}
	return 0;
}
// DEBUG }
/* Sample output:

timedwait failed as expected
wait succeeded
wait succeeded
wait succeeded

*/
