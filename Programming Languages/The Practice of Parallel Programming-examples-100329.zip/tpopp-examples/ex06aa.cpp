#include <pthread.h>

// [[ex06aa]]
// DEBUG descr A wrapper class for the thread-specific data key.
class tskey
{
public:
	// the subclass must define its own static value
	// destructor function and pass it to the tskey
	// constructor
	typedef void value_destructor(void *val);

	tskey(value_destructor *df)
	{
		pthread_key_create(&key_, df);
	}
	virtual ~tskey()
	{
		pthread_key_delete(key_);
	}

	void *get()
	{
		return pthread_getspecific(key_);
	}

	void set(void *val)
	{
		pthread_setspecific(key_, val);
	}
protected:
	pthread_key_t key_;
};
// END
