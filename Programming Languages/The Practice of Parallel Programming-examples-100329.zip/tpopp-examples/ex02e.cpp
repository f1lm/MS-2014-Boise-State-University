#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "ptwrap.hpp"

void ex02ea()
{
// [[ex02ea]]
// DEBUG descr The basic use of the mutex chaining class.
pw::pmutex mutex1;
pw::pmcond cond;
// ...
{
	pw::lockmutex lm(mutex1);
	// ...
	{
		// pmcond inherits from pmutex
		pw::swapmutex sm(mutex1, cond); 
		cond.wait();
	} 
	// now mutex1 is locked back and cond is unlocked
	// ...
}
// END
}

void ex02eb()
{
// [[ex02eb]]
// DEBUG descr Synchronization of a condition variable with a read-write lock using the manual lock chaining.
pw::prwlock rw1;
pw::pmcond cond;
// ...
{
	pw::lockwr lw(rw1);
	// ...
	{
		cond.lock(); // pmcond inherits from mutex
		rw1.unlock();

		cond.wait();

		cond.unlock();
		rw1.wrlock();
	} // now rw1 is locked back
	// ...
}
// END
}
