#include "pwext.hpp"
#include <list>
#include <stdio.h>

class data;
void exchange_data(std::list<data *> &dlist)
{
	// DEBUG {
	fprintf(stderr, "---\n");
	// DEBUG }
}

// data used by the workers, its contents is not important here
class data;

// [[ex03ck]]
// DEBUG descr A barrier implementation with a semaphore and a condition variable.
class barrier 
{
public:
	barrier(int count) :
		flip_(0), flop_(0), generation_(false), 
		count_(count)
	{ }

	// May be called only by the control thread, to adjust
	// the number of workers
	int add_workers(int add)
	{
		count_ += add; // add may be negative
		return count_;
	}

	// Workers call this method to synchronize on the
	// barrier
	void sync()
	{
		pw::lockmutex lm(flop_);
		bool gen = generation_;
		flip_.signal(1);
		while(gen == generation_)
			flop_.wait();
	}

	// Control calls this method to wait for the barrier
	// to be reached by all the workers
	void wait()
	{
		flip_.wait(count_);
	}

	// Control calls this method to release the workers
	// from the barrier
	void signal()
	{
		pw::lockmutex lm(flop_);
		generation_ = !generation_;
		flop_.broadcast();
	}

protected:
	// control waits for workers
	pw::semaphore flip_; 
	// workers wait for control
	pw::pmcond flop_; 
	// alternates between the steps
	bool generation_; 
	// number of worker threads synchronized by the
	// barrier
	int count_; 
};
// END

// DEBUG {
// copy of ex03ch
class worker : public pw::pwthread
{
public:
	worker(data *d, barrier *b) :
		data_(d), barrier_(b), stop_(false)
	{ }

	virtual void *execute()
	{
		while (!stop_) {
			// ... perform the computations ...
	// DEBUG {
			fprintf(stderr, "worker %p step data %p\n", this, data_);
	// DEBUG }
			barrier_->sync();
		}
		return 0;
	}

	void stop()
	{
		stop_ = true;
	}

protected:
	data *data_;
	barrier *barrier_;
	bool stop_;
};

// the function running in the control thread, processes
// a list of data in parallel
void control(std::list<data *> &dlist, int steps)
{
	barrier bar(0);
	std::list <worker *> workers;

	// prepare the data elements
	exchange_data(dlist);

	// start the workers
	for (std::list<data *>::iterator it = dlist.begin(); it != dlist.end(); ++it) {
		worker *w = new worker(*it, &bar);
		workers.push_back(w);
		bar.add_workers(1);
		w->start();
	}

	for (int i = 1; i < steps; i++) {
		bar.wait();
		exchange_data(dlist);
		bar.signal();
	}

	// all the calculations are done
	bar.wait();
	for (std::list<worker *>::iterator it = workers.begin(); it != workers.end(); ++it) 
		(*it)->stop();
	bar.signal();

	for (std::list<worker *>::iterator it = workers.begin(); it != workers.end(); ++it) {
		(*it)->join();
		delete (*it);
	}
}

class data {
public:
	int x_;
};

int main()
{
	std::list<data *> dd;
	dd.push_back(new data);
	dd.push_back(new data);
	dd.push_back(new data);
	control(dd, 3);
	while(!dd.empty()) {
		delete dd.front();
		dd.pop_front();
	}
	return 0;
}
// DEBUG }
/* Sample output:
---
worker 0x11600d0 step data 0x1160010
worker 0x1160290 step data 0x1160050
worker 0x1160450 step data 0x1160090
---
worker 0x1160290 step data 0x1160050
worker 0x11600d0 step data 0x1160010
worker 0x1160450 step data 0x1160090
---
worker 0x11600d0 step data 0x1160010
worker 0x1160290 step data 0x1160050
worker 0x1160450 step data 0x1160090
*/
