#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "ptwrap.hpp"

// this is not semantically correct but good enough for syntax checking
typedef pw::pmutex recmutex;

class MyClass 
{
public:
// DEBUG to here

// [[ex02fc]]
// DEBUG descr A workaround for the deadlock with recursive mutexes.
	void foo() 
	{
		mutex1_.lock();
		mutex2_.lock();
		// ...
		bar();
		// ...
		mutex2_.unlock();
		mutex1_.unlock();
	}
// END


	// DEBUG from here
	void bar() 
	{
		mutex1_.lock();
		// ...
		mutex1_.unlock();
	}
	void baz() 
	{
		mutex1_.lock();
		mutex2_.lock();
		// ...
		mutex2_.unlock();
		mutex1_.unlock();
	}

protected:
	recmutex mutex1_, mutex2_; // some recursive mutex class...
};

