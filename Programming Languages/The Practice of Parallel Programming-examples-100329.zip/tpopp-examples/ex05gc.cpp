#include <stdio.h>
#include <string>
#include "pwext.hpp"

// copied from ex05ga
class logger
{
public:
	static logger instance;

	void open(const std::string &path);
	void log(const std::string &s);

protected:
	logger();
	~logger();
};
logger logger::instance;

// [[ex05gc]]
// DEBUG descr A singleton object created on demand.
class server_connection
{
public:
	static server_connection *get()
	{
		pw::lockmutex lm(mutex_);
		if (instance_ == 0)
			instance_ = new server_connection;
		return instance_;
	}
	static void destroy()
	{
		pw::lockmutex lm(mutex_);
		delete instance_;
		instance_ = 0;
	}
	void open(const std::string &address) 
	{
		// ...
		logger::instance.log(
			"server_connection opened connection to "
			+ address);
	}
	void close();

protected:
	server_connection();
	~server_connection()
	{
		close();
		// ...
	}

	static pw::pmutex mutex_; // controls all access
	static server_connection *instance_;
	// ...
};
// END

