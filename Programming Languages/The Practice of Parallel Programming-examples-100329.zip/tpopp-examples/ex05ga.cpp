#include <stdio.h>
#include <string>

// [[ex05ga]]
// DEBUG descr A program with a singleton.
class logger
{
public:
	static logger instance;

	void open(const std::string &path);
	void log(const std::string &s);

protected:
	logger();
	~logger();
};
logger logger::instance;

//... somewhere in the code

class bar
{
public:
	bar();

	void do_bar(int x)
	{
		// ...
		logger::instance.log(
			"error: bad parameters to method bar::bar()");
		// ...
	}
};

class foo
{
public:
	foo();

	void do_foo(int a, int b)
	{
		// ...
		logger::instance.log(
			"error: bad parameters to method foo::foo()");
		// ...
		bar mybar;
		mybar.do_bar(b);
		// ...
	}
};

void baz(int x)
{
	// ...
	logger::instance.log(
		"error: bad parameters to function baz()");
	// ...
}

int main(int argc, char **argv)
{
	// ...
	logger::instance.open(argc > 1? argv[1] : "/tmp/log");
	foo myfoo;
	// ...
	myfoo.do_foo(1, 2);
	baz(3);
	// ...
}
// END

// DEBUG {
void logger::open(const std::string &path)
{
	fprintf(stderr, "logger::open()\n");
}
void logger::log(const std::string &s)
{
	fprintf(stderr, "%s\n", s.c_str());
}
logger::logger()
{
	fprintf(stderr, "logger instance created\n");
}
logger::~logger()
{
	fprintf(stderr, "logger instance destroyed\n");
}

foo::foo()
{ }
bar::bar()
{ }
// DEBUG }

/* Sample output:
logger instance created
logger::open()
error: bad parameters to method foo::foo()
error: bad parameters to method bar::bar()
error: bad parameters to function baz()
logger instance destroyed
*/
