#include "ptwrap.hpp"
#include <deque>
#include <stdio.h>
#include <assert.h>

struct Message 
{
	Message(int mtype) : msgtype_(mtype)
	{ }
	virtual ~Message() { } // allow for polymorphism

	enum {
		EXIT,
		CANCEL,
		NORMAL // first normal type
	};
	int msgtype_;
	// ... whatever else is needed by the application ...
};

// [[ex04cj]]
// DEBUG descr The queue post method allowing the cancellation and guaranteeing the ordering of control messages.
class Queue
{
public:
	// DEBUG {
	enum {
		DEFAULT_LIMIT = 1000
	};

	Queue(int limit = DEFAULT_LIMIT) :
		limit_(limit), 
		dqwr_(&deque1_), dqrd_(&deque2_), condrd_(condwr_),
		exitposted_(false), nwriters_(0)
	{ }
	virtual ~Queue()
	{ 
		dispose(deque1_);
		dispose(deque2_);
	}
	// DEBUG }
	// ...
	virtual bool post(Message *m)
	{
		{
			pw::lockmutex lm(mutexx_);
			bool pushlocked = false;
			if (exitposted_) {
				delete m;
				return false;
			}
			switch (m->msgtype_) {
			case Message::CANCEL:
				clear(); // then the posting is done as usual...
				pushlocked = true;
				break;
			case Message::EXIT:
				// ...
	// DEBUG {
			if (--nwriters_ <= 0) {
				// last writer, post EXIT to the handler
				exitposted_ = true;
			} else {
				// message is processed successfully but it has
				// nothing to pass to the handler yet
				delete m;
				return true;
			}
	// DEBUG }
				pushlocked = true;
				break;
			// ...
			}
			if (pushlocked) {
				push_back(m);
				return true;
			}
		}
		push_back(m);
		return true;
	}
	// ...
	// DEBUG {
	Message *pop_front()
	{
		pw::lockmutex lm(mutexrd_);

		while(dqrd_->empty()) {
			{
				pw::lockmutex lmw(condwr_);

				if (!dqwr_->empty()) {
					swap(dqwr_, dqrd_);
					// if the write buffer was full, wake up the writers
					condwr_.broadcast();
				}
			}
			if(dqrd_->empty()) {
				pw::swapmutex sw(mutexrd_, condwr_);

				if (dqwr_->empty())
					condrd_.wait(); 
			}
		}

		Message *m = dqrd_->front();
		dqrd_->pop_front();
		return m;
	}
	// virtual in case if later a subclass wants to do something different;
	// returns true on success, or false if the handler has already been told
	// to exit
	virtual bool add_writer()
	{ 
		pw::lockmutex lm(mutexx_);
		if (exitposted_)
			return false;
		++nwriters_;
		return true;
	}

protected:
	// Caller must have the mutex in condwr_ locked.
	void push_back_l(Message *m)
	{
		while (dqwr_->size() >= limit_)
			condwr_.wait(); // it releases and gets back the mutex

		dqwr_->push_back(m);
		condrd_.broadcast();
	}
	void push_back(Message *m)
	{
		pw::lockmutex lm(condwr_);
		push_back_l(m);
	}
	void clear() 
	{
		pw::lockmutex lmr(mutexrd_);
		pw::lockmutex lmw(condwr_);

		dispose(*dqrd_);
		dispose(*dqwr_);

		// if the write buffer was full, wake up the writers
		condwr_.broadcast();
	}
	void dispose(std::deque<Message *> &deq)
	{ 
		Message *m;
		while (!deq.empty()) {
			m = deq.front();
			deq.pop_front();
			delete m;
		}
	}

	int limit_;
	std::deque<Message *> deque1_, deque2_;
	pw::pmutex mutexrd_;
	std::deque<Message *> *dqwr_, *dqrd_;
	pw::pmcond condwr_;
	pw::pchaincond condrd_;
	pw::pmutex mutexx_; // for the exit accounting
	bool exitposted_; // whether the EXIT message was posted to the queue
	int nwriters_; // number of writers that haven't already exited
	// DEBUG }
};
// END

// DEBUG {
struct data : public Message
{
	int v_;

	data(int v, int kind = NORMAL) : Message(kind), v_(v)
	{ }
	~data()
	{
		fprintf(stderr, "deleted data %d\n", v_);
	}
};

int main()
{
	Queue q;
	q.add_writer();
	q.post(new data(1));
	q.post(new data(2));
	data * v2 = static_cast<data *>(q.pop_front());
	assert(v2->v_ == 1);
	delete v2;
	return 0;
}
/* Sample output:
deleted data 1
deleted data 2
*/
// DEBUG }
