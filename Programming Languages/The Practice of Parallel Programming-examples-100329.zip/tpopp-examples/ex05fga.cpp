#include "pwref.hpp"
#include <stdio.h>
#include <stdlib.h>

// same thing as ex05fg but gets all the relevant classes through pwref.hpp

// DEBUG from
class mytarget : public pw::reftarget
{
public:
	mytarget() :
		pw::reftarget(this)
	{ }

	~mytarget()
	{
		invalidate();
	}
};

int main()
{
	mytarget *t = new mytarget;
	pw::weakref *r = t->newweakref();
	{
		mytarget *tt;
		pw::scopegrab<mytarget> scope(r, tt);
		if (tt) {
			fprintf(stderr, "target is still valid\n");
		}
		{
			pw::scopeungrab<mytarget> unscope(scope, tt);
			delete t;
		}
		if (!tt) {
			fprintf(stderr, "target is not valid any more\n");
		}
	}
	return 0;
}

/* Sample result:
target is still valid
target is not valid any more
*/
