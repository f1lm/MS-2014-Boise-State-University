#include "pwext.hpp"
#include <list>

// [[ex03cg]]
// DEBUG descr A simple barrier implemented with a semaphore.
// data used by the workers, its contents is not
// important here
class data;

class worker : public pw::pwthread
{
public:
	worker(data *d, pw::semaphore *initsem) :
		data_(d), initsem_(initsem)
	{ }

	virtual void *execute()
	{
		// ... initialize ...
		initsem_->signal(1);
		// .. continue the normal work
		return 0;
	}

protected:
	data *data_;
	pw::semaphore *initsem_;
};

// the function running in the control thread,
// processes a list of data in parallel
void control(std::list<data *> &dlist)
{
	pw::semaphore initworkers(0);
	std::list <worker *> workers;

	int nworkers = 0;
	for (std::list<data *>::iterator it = dlist.begin(); 
			it != dlist.end(); ++it) {
		nworkers++;
		worker *w = new worker(*it, &initworkers);
		workers.push_back(w);
		w->start();
	}

	initworkers.wait(nworkers);
	// all workers are known to have completed the
	// initialization ...
	// ... continue ...
	// DEBUG {
	for (std::list<worker *>::iterator it = workers.begin(); it != workers.end(); ++it) {
		(*it)->join();
		delete (*it);
	}
	// DEBUG }
}
// END

// DEBUG {
class data {
public:
	int x_;
};

int main()
{
	std::list<data *> dd;
	dd.push_back(new data);
	dd.push_back(new data);
	dd.push_back(new data);
	control(dd);
	while(!dd.empty()) {
		delete dd.front();
		dd.pop_front();
	}
	return 0;
}
// DEBUG }
