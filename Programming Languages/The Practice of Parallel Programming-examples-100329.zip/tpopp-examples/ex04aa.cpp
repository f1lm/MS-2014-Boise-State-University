#include "ptwrap.hpp"
#include <deque>

// [[ex04aa]]
// DEBUG descr A simple-minded synchronized queue.
template <class Value>
class Queue
{
public:
	Queue()
	{ }

	virtual ~Queue()
	{ }

	// this combines the semantics of STL front() and
	// pop_front() since the popping must be atomic
	Value pop_front()
	{
		pw::lockmutex lm(lock_);
		Value v = deque_.front();
		deque_.pop_front();
		return v;
	}

	void push_back(Value &v)
	{
		pw::lockmutex lm(lock_);
		deque_.push_back(v);
	}

protected:
	std::deque<Value> deque_;
	pw::pmutex lock_;
};
// END

// DEBUG {
int main()
{
	Queue<int> q;
	int v1 = 1;
	q.push_back(v1);
	int v2 = q.pop_front();
	return !(v1 == v2);
}
// DEBUG }
