#ifndef __pwref_hpp__
#define __pwref_hpp__
#include "pwext.hpp"
#include <stdio.h>
#include <stdlib.h>

#define EX05_NESTED
namespace pw {
#include "ex05fc.cpp"
#include "ex05ff.cpp"
#include "ex05fg.cpp"
};
#undef EX05_NESTED

#endif // __pwref_hpp__
