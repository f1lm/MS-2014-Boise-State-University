using System;

namespace Sample_code
{

     class Class1
     {
           [STAThread]
           public static void Main()
           {
                  Class1 pgm = new Class1();
                  pgm.Go();
                 

           }


          public void Go()
          {
             Thing x = new Animal();
            
             Switcharoo(ref x);

              Console.WriteLine(
                "x is Animal    :   "
                + (x is Animal).ToString());

              Console.WriteLine(
                  "x is Vegetable :   " 
                  + (x is Vegetable).ToString());
               
          }

           public class Thing
           {
           }

           public class Animal:Thing
           {
               public int Weight;
           }

           public class Vegetable:Thing
           {
               public int Length;
           }

           public void Switcharoo(ref Thing pValue)
           {
               pValue = new Vegetable();
           }
     }
}
