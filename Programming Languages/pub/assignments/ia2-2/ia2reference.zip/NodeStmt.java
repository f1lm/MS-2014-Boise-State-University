// NodeStmt.java - a node of statement.

public class NodeStmt extends Node {

}
