// NodeFactId.java - a node of fact=id.

public class NodeFactId extends NodeFact {

    private String id;
    private boolean negative=false; 

    /**
     * Constructors
     * @param pos
     * @param id
     */
    public NodeFactId(int pos, String id) {
		this.pos=pos;
		this.id=id;
    }
    
    public NodeFactId(int pos, String id, boolean negative) {
    	this.pos=pos;
		this.id=id;
		this.negative=negative;
    }

    /**
     * Evaluate id: this will return 0.
     */
    public double eval(Environment env) throws EvalException {
    	if(negative)
    		return 0-env.get(pos, id);
    	return env.get(pos,id);
    }

}
