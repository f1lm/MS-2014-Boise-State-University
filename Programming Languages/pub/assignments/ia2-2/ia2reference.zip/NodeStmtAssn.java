// NodeStmtAssn.java
public class NodeStmtAssn extends NodeStmt {
	
	private NodeAssn assn;
	
	/**
	 * Constructor
	 * @param assn
	 */
	public NodeStmtAssn(NodeAssn assn) {
		this.assn=assn;
	}
	
	/**
	 * Evaluate the statement.
	 */
	public double eval(Environment env) throws EvalException {
		if(assn==null)
			return 0;
	 	return assn.eval(env);
	}
}
