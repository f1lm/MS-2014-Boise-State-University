// SyntaxException.java

public class SyntaxException extends Exception {

    /**
	 * default serial id.
	 */
	private static final long serialVersionUID = 1L;
	private int pos;
    private Token expected;
    private Token found;

    /**
     * Constructor
     * @param pos
     * @param expected
     * @param found
     */
    public SyntaxException(int pos, Token expected, Token found) {
		this.pos=pos;
		this.expected=expected;
		this.found=found;
    }

    /**
     * A string representation of the SyntaxException.
     */
    public String toString() {
		return "syntax error"
		    +", pos="+pos
		    +", expected="+expected
		    +", found="+found;
    }

}
