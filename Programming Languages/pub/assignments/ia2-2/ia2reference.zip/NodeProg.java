// NodeProg.java

public class NodeProg extends Node {
	
	private NodeBlock block;

    /**
     * Constructor
     * @param assn
     */
    public NodeProg(NodeBlock block) {
    	this.block=block;
    }

    /**
     * Evaluate the statement.
     */
    public double eval(Environment env) throws EvalException {
    	if(block==null)
    		return 0;
    	return block.eval(env);
    }
	
}
