// NodeFactExpr.java - a fact node when fact is expr.

public class NodeFactExpr extends NodeFact {

    private NodeExpr expr;
    private boolean negative;

    /**
     * Constructors.
     * @param expr
     */
    public NodeFactExpr(NodeExpr expr) {
    	this.expr=expr;
    }
    public NodeFactExpr(NodeExpr expr, boolean negative) {
    	this.expr=expr;
    	this.negative=negative;
    }

    /**
     * Evaluate the expression.
     */
    public double eval(Environment env) throws EvalException {
    	if(negative)
    		return 0-expr.eval(env);
    	return expr.eval(env);
    }

}
