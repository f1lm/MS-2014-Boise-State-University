// NodeWhileDo.java

public class NodeWhileDo extends NodeStmt {

	private NodeBoolexpr boolexpr;
	private NodeStmt stmt;
	
	/**
	 * Constructor
	 * @param boolexpr
	 * @param stmt
	 */
	public NodeWhileDo(NodeBoolexpr boolexpr, NodeStmt stmt) {
		this.boolexpr = boolexpr;
		this.stmt = stmt;
	}
	
	/**
	 * Evaluate while-do block.
	 */
	public double eval(Environment env) throws EvalException {
		while(boolexpr.eval(env)==1.0)
			stmt.eval(env);
		return 0;
	}
	
}
