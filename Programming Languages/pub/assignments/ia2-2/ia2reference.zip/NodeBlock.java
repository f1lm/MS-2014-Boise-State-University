// NodeBlock.java

public class NodeBlock extends Node {

    private NodeStmt stmt;
    private NodeBlock block;
	
    /**
     * Constructor.
     * @param stmt
     */
    public NodeBlock(NodeStmt stmt, NodeBlock block) { 
    	this.stmt = stmt;
    	this.block = block;
    }
    
    // No need evaluating a block.
	public double eval(Environment env) throws EvalException {
		stmt.eval(env);
//		if (block!=null)
//			block.eval(env);
		//System.out.println(stmt.eval(env));
		if (block!=null)
			return block.eval(env); // always return block.
		return 0.0;
	}
	
}
