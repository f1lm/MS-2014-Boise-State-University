import java.util.HashMap;

// Environment.java

public class Environment {

	HashMap<String, Double> usedIds = new HashMap<String, Double>();
	
    public double put(String var, Double val) {
    	usedIds.put(var, val);
    	return val;
    }
    public double get(int pos, String var) throws EvalException {
    	Double value = usedIds.get(var);
    	if(value!=null)
    		return value;
    	else
    		throw new EvalException(pos, "Variable " + var + " not defined.");
    }

}
