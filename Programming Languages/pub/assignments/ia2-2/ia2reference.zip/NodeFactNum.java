// NodeFactNum.java - a fact node when fact is number.

public class NodeFactNum extends NodeFact {

    private String num;
    private boolean negative = false;

    /**
     * Constructors
     * @param num
     */
    public NodeFactNum(String num) {
    	this.num=num;
    }
    public NodeFactNum(String num, boolean negative) {
    	this.num=num;
    	this.negative = negative;
    }

    /**
     * Evaluate number.
     */
    public double eval(Environment env) throws EvalException {
    	if(negative)
    		return 0-Double.parseDouble(num);
    	return Double.parseDouble(num);
    }

}
