// Token.java - Token class.

public class Token {

    private String token; // token type
    private String lexeme; // token detail

    /**
     * Constructor1.
     * @param token
     * @param lexeme
     */
    public Token(String token, String lexeme) {
		this.token=token;
		this.lexeme=lexeme;
    }

    /**
     * Constructor2. without specify the type/content of token.
     * @param token
     */
    public Token(String token) {
    	this(token,token);
    }

    /**
     * Return the token string.
     * @return
     */
    public String tok() { return token; } 
    
    /**
     * Return the lexeme string.
     * @return
     */
    public String lex() { return lexeme; }

    /**
     * Decide if two tokens are equivalent by comparing their token type.
     * @param t
     * @return
     */
    public boolean equals(Token t) {
    	return token.equals(t.token);
    }

    /**
     * Return a string representing the token.
     */
    public String toString() {
    	return "<"+tok()+","+lex()+">";
    }

}
