// Interpreter.java - main class.

public class Interpreter {

    public static void main(String[] args) {
    	Parser parser=new Parser();
    	Environment env=new Environment();
    	String str = ""; // ia-2: treat all arguments as one program.
    	for (String prog: args) {
    		if (!(prog.startsWith("[")&&prog.endsWith("]"))) {
    			str += " ";
    			str += prog;
    		}
    	}
		// Read double value from standard input.
	    java.util.Scanner input = new java.util.Scanner(System.in);
		try {
			NodeProg node = (NodeProg) (parser.parse(str.trim(), input));
			if (node!=null) {
				node.eval(env); // ia-2: do not print each statement.		
				//System.out.println(node.eval(env)); 
				//System.out.println("Parsing done.");
			}
		} catch (SyntaxException e) {
			System.err.println(e);
		} catch (EvalException e) {
			e.printStackTrace();
		}
		input.close();
    }

}
