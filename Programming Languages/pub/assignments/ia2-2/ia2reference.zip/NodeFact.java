// NodeFact.java - simply extends Node

public abstract class NodeFact extends Node {}

