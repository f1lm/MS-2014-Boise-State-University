// Node.java = define a node with position

public abstract class Node {

    protected int pos=0; // indicates the position in the program.

    /**
     * Throw an error message.
     * @param env
     * @return
     * @throws EvalException
     */
    public double eval(Environment env) throws EvalException {
    	throw new EvalException(pos,"cannot eval() node!");
    }

}
