// NodeRelop.java
// relational operator.

public class NodeRelop extends Node {

    private String relop;

    /**
     * Constructor
     * @param pos
     * @param relop
     */
    public NodeRelop(int pos, String relop) {
		this.pos=pos;
		this.relop=relop;
    }

    /**
     * Return the evaluation of the relational operation. return boolean values
     * as double values.
     * @param o1
     * @param o2
     * @return o1<o2 or o1<=o2 or o1>o2 or o1>=o2 or o1<>o2 or o1==o2
     * 1.0 for true; 0.0 for false.
     * @throws EvalException
     */
    public double op(double o1, double o2) throws EvalException {
		if (relop.equals("<"))
		    return o1<o2 ? 1.0 : 0.0;
		if (relop.equals("<="))
			return o1<=o2 ? 1.0 : 0.0;
		if (relop.equals(">"))
		    return o1>o2 ? 1.0 : 0.0;
		if (relop.equals(">="))
			return o1>=o2 ? 1.0 : 0.0;
		if (relop.equals("<>"))
		    return o1!=o2 ? 1.0 : 0.0;
		if (relop.equals("=="))
			return o1==o2 ? 1.0 : 0.0;
		throw new EvalException(pos,"bogus mulop: "+relop);
    }

}
