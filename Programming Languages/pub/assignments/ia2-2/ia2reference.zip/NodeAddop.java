// NodeAddop.java

public class NodeAddop extends Node {

    private String addop;

    /**
     * Constructor.
     * @param pos
     * @param addop
     */
    public NodeAddop(int pos, String addop) {
		this.pos=pos;
		this.addop=addop;
    }

    /**
     * Return the evaluation of +/- operation
     * @param o1
     * @param o2
     * @return o1+o2 or o1-o2
     * @throws EvalException
     */
    public double op(double o1, double o2) throws EvalException {
		if (addop.equals("+"))
		    return o1+o2;
		if (addop.equals("-"))
		    return o1-o2;
		throw new EvalException(pos,"bogus addop: "+addop);
    }

}
