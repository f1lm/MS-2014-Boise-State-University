package org.sales.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.sales.Item;

public class ItemTestCase {

	private Item item;
	private ArrayList<Item> itemList = new ArrayList<Item>();

	@Before
	public void setUp() throws Exception {
		item = new Item("iPhone", 2000, 2);
		itemList.add(item);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetItemTotal() {
		double subTotal = 0.0;
		for (Item item : itemList) {
			// buy one, get the second (and the rest of the same item) 50% off
			subTotal += item.getItemTotal(true);
		}
		assertEquals(3000, subTotal, 0.1);
	}

}
