package org.sales;

public enum CustomerType {
	SENIORS, PREFERRED, OTHERS;
}
