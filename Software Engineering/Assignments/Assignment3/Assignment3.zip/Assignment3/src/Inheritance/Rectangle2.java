package Inheritance;

public class Rectangle2 extends Square2 {

	public void setLength(double size) {
		super.setSide(size);
	}

	public void setWidth(double size) {
		super.setSide(size);
	}
}
