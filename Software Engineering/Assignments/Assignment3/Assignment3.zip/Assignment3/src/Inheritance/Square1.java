package Inheritance;

public class Square1 extends Rectangle1 {

	public void setSide(double size) {
		super.setLength(size);
		super.setWidth(size);
	}	
}
