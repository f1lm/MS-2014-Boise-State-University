package Cohesion;

public class BusFee {
	private int busFee;

	public void payBusFee(int amount) {
	}

	public int getBusFee() {
		return busFee;
	}

	public void setBusFee(int busFee) {
		this.busFee = busFee;
	}
}
