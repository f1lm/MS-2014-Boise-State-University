package Cohesion;

public class BusDriver {
	private String driver;

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public BusDriver(String driver) {
		this.driver = driver;
	}
}
