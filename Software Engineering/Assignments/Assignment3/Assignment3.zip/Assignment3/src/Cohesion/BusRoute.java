package Cohesion;

public class BusRoute {
	public void getBusRoute(String start, String end) {
	}
}
