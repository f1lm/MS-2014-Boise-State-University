SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Insurance`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Insurance` (
  `Insurance_ID` INT NOT NULL ,
  `phone` VARCHAR(20) NOT NULL ,
  `SSN` INT NOT NULL ,
  `StartingDate` DATE NOT NULL ,
  `EndingDate` DATE NOT NULL ,
  PRIMARY KEY (`Insurance_ID`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`PatientInfo`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`PatientInfo` (
  `PatientID` INT NOT NULL ,
  `Patient_Name` VARCHAR(45) NOT NULL ,
  `DateOfBirth` DATE NOT NULL ,
  `Address` VARCHAR(45) NULL ,
  `Medical_Condition` VARCHAR(45) NULL ,
  `Insurance_Insurance_ID` INT NOT NULL ,
  PRIMARY KEY (`PatientID`) ,
  INDEX `fk_PatientInfo_Insurance1` (`Insurance_Insurance_ID` ASC) ,
  CONSTRAINT `fk_PatientInfo_Insurance1`
    FOREIGN KEY (`Insurance_Insurance_ID` )
    REFERENCES `mydb`.`Insurance` (`Insurance_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Institution`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Institution` (
  `InstitutionName` VARCHAR(45) NOT NULL ,
  `Location` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`InstitutionName`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Physician`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Physician` (
  `Staff_ID` INT NOT NULL ,
  `Physician_Name` VARCHAR(45) NOT NULL ,
  `Degree` VARCHAR(45) NOT NULL ,
  `AreaOfSpecialization` VARCHAR(45) NOT NULL ,
  `Institution_InstitutionNo` INT NOT NULL ,
  `Institution_InstitutionName` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`Staff_ID`) ,
  INDEX `fk_Physician_Institution1` (`Institution_InstitutionName` ASC) ,
  CONSTRAINT `fk_Physician_Institution1`
    FOREIGN KEY (`Institution_InstitutionName` )
    REFERENCES `mydb`.`Institution` (`InstitutionName` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Pharmacy`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Pharmacy` (
  `PharmacyNum` INT NOT NULL ,
  `PharmacyName` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`PharmacyNum`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Prescription`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Prescription` (
  `PrescriptionID` INT NOT NULL AUTO_INCREMENT ,
  `MedicineName` VARCHAR(45) NOT NULL ,
  `Amount` INT NOT NULL ,
  `PatientInfo_PatientID` INT NOT NULL ,
  `Pharmacy_PharmacyNo1` INT NOT NULL ,
  `Pharmacy_PharmacyNo2` INT NOT NULL ,
  PRIMARY KEY (`PrescriptionID`) ,
  INDEX `fk_Prescription_PatientInfo1` (`PatientInfo_PatientID` ASC) ,
  INDEX `T` (`Pharmacy_PharmacyNo1` ASC) ,
  INDEX `fk_Prescription_Pharmacy1` (`Pharmacy_PharmacyNo2` ASC) ,
  CONSTRAINT `fk_Prescription_PatientInfo1`
    FOREIGN KEY (`PatientInfo_PatientID` )
    REFERENCES `mydb`.`PatientInfo` (`PatientID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `T`
    FOREIGN KEY (`Pharmacy_PharmacyNo1` )
    REFERENCES `mydb`.`Pharmacy` (`PharmacyNum` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Prescription_Pharmacy1`
    FOREIGN KEY (`Pharmacy_PharmacyNo2` )
    REFERENCES `mydb`.`Pharmacy` (`PharmacyNum` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`FutureAppointment`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`FutureAppointment` (
  `AppointmentID` INT NOT NULL AUTO_INCREMENT ,
  `AppointmentDate` DATETIME NOT NULL ,
  `PatientInfo_PatientID` INT NOT NULL ,
  `Physician_Physician_ID` INT NOT NULL ,
  PRIMARY KEY (`AppointmentID`) ,
  INDEX `fk_Appointment_PatientInfo1` (`PatientInfo_PatientID` ASC) ,
  INDEX `fk_Appointment_Physician1` (`Physician_Physician_ID` ASC) ,
  CONSTRAINT `fk_Appointment_PatientInfo1`
    FOREIGN KEY (`PatientInfo_PatientID` )
    REFERENCES `mydb`.`PatientInfo` (`PatientID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Appointment_Physician1`
    FOREIGN KEY (`Physician_Physician_ID` )
    REFERENCES `mydb`.`Physician` (`Staff_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`LivingWill`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`LivingWill` (
  `PatientInfo_PatientID` INT NOT NULL ,
  `DecisionMaker1` VARCHAR(45) NULL ,
  `DecisionMaker2` VARCHAR(45) NULL ,
  `DecisionMaker3` VARCHAR(45) NULL ,
  `DecisionMaker4` VARCHAR(45) NULL ,
  `Living_Will` VARCHAR(45) NULL ,
  INDEX `fk_LivingWill_PatientInfo1` (`PatientInfo_PatientID` ASC) ,
  PRIMARY KEY (`PatientInfo_PatientID`) ,
  CONSTRAINT `fk_LivingWill_PatientInfo1`
    FOREIGN KEY (`PatientInfo_PatientID` )
    REFERENCES `mydb`.`PatientInfo` (`PatientID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`HistoryAppointment`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`HistoryAppointment` (
  `AppointmentID` INT NOT NULL AUTO_INCREMENT ,
  `AppointmentDate` DATETIME NOT NULL ,
  `PatientInfo_PatientID` INT NOT NULL ,
  `Physician_Physician_ID` INT NOT NULL ,
  PRIMARY KEY (`AppointmentID`) ,
  INDEX `fk_HistoryAppointment_PatientInfo1` (`PatientInfo_PatientID` ASC) ,
  INDEX `fk_HistoryAppointment_Physician1` (`Physician_Physician_ID` ASC) ,
  CONSTRAINT `fk_HistoryAppointment_PatientInfo1`
    FOREIGN KEY (`PatientInfo_PatientID` )
    REFERENCES `mydb`.`PatientInfo` (`PatientID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_HistoryAppointment_Physician1`
    FOREIGN KEY (`Physician_Physician_ID` )
    REFERENCES `mydb`.`Physician` (`Staff_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`WorkSheet`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`WorkSheet` (
  `Physician_Physician_ID` INT NOT NULL ,
  `Institution_InstitutionName` VARCHAR(45) NOT NULL ,
  `Time` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`Physician_Physician_ID`, `Institution_InstitutionName`, `Time`) ,
  INDEX `fk_WorkSheet_Institution1` (`Institution_InstitutionName` ASC) ,
  CONSTRAINT `fk_WorkSheet_Physician1`
    FOREIGN KEY (`Physician_Physician_ID` )
    REFERENCES `mydb`.`Physician` (`Staff_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_WorkSheet_Institution1`
    FOREIGN KEY (`Institution_InstitutionName` )
    REFERENCES `mydb`.`Institution` (`InstitutionName` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Diagnosis`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Diagnosis` (
  `HistoryAppointment_AppointmentID` INT NOT NULL ,
  `Physician_Staff_ID` INT NOT NULL ,
  `PatientInfo_PatientID` INT NOT NULL ,
  `PatientInfo_SSN` INT NOT NULL ,
  `Details` VARCHAR(45) NOT NULL ,
  `Diagnosiscol` DATETIME NOT NULL ,
  INDEX `fk_Diagnosis_Physician1` (`Physician_Staff_ID` ASC) ,
  INDEX `fk_Diagnosis_PatientInfo1` (`PatientInfo_PatientID` ASC, `PatientInfo_SSN` ASC) ,
  PRIMARY KEY (`HistoryAppointment_AppointmentID`) ,
  CONSTRAINT `fk_Diagnosis_Physician1`
    FOREIGN KEY (`Physician_Staff_ID` )
    REFERENCES `mydb`.`Physician` (`Staff_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Diagnosis_PatientInfo1`
    FOREIGN KEY (`PatientInfo_PatientID` )
    REFERENCES `mydb`.`PatientInfo` (`PatientID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Diagnosis_HistoryAppointment1`
    FOREIGN KEY (`HistoryAppointment_AppointmentID` )
    REFERENCES `mydb`.`HistoryAppointment` (`AppointmentID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`MedicalCondition`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`MedicalCondition` (
  `Index` INT NOT NULL ,
  `Diagnosis_HistoryAppointment_AppointmentID` INT NOT NULL ,
  `Condition` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`Index`, `Diagnosis_HistoryAppointment_AppointmentID`) ,
  INDEX `fk_MedicalCondition_Diagnosis1` (`Diagnosis_HistoryAppointment_AppointmentID` ASC) ,
  CONSTRAINT `fk_MedicalCondition_Diagnosis1`
    FOREIGN KEY (`Diagnosis_HistoryAppointment_AppointmentID` )
    REFERENCES `mydb`.`Diagnosis` (`HistoryAppointment_AppointmentID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`TreatPlan`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`TreatPlan` (
  `MedicalCondition_Index` INT NOT NULL ,
  `MedicalCondition_Diagnosis_HistoryAppointment_AppointmentID` INT NOT NULL ,
  `Content` VARCHAR(45) NOT NULL ,
  `Prescription_PrescriptionID` INT NOT NULL ,
  INDEX `fk_TreatPlan_Prescription1` (`Prescription_PrescriptionID` ASC) ,
  PRIMARY KEY (`MedicalCondition_Index`, `MedicalCondition_Diagnosis_HistoryAppointment_AppointmentID`) ,
  CONSTRAINT `fk_TreatPlan_Prescription1`
    FOREIGN KEY (`Prescription_PrescriptionID` )
    REFERENCES `mydb`.`Prescription` (`PrescriptionID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TreatPlan_MedicalCondition1`
    FOREIGN KEY (`MedicalCondition_Index` , `MedicalCondition_Diagnosis_HistoryAppointment_AppointmentID` )
    REFERENCES `mydb`.`MedicalCondition` (`Index` , `Diagnosis_HistoryAppointment_AppointmentID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Nurse`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Nurse` (
  `Staff_ID` INT NOT NULL ,
  `Institution_InstitutionName` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`Staff_ID`) ,
  INDEX `fk_Nurse_Institution1` (`Institution_InstitutionName` ASC) ,
  CONSTRAINT `fk_Nurse_Institution1`
    FOREIGN KEY (`Institution_InstitutionName` )
    REFERENCES `mydb`.`Institution` (`InstitutionName` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`VisitRecord`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`VisitRecord` (
  `RecordNo` INT NOT NULL AUTO_INCREMENT ,
  `Temperature` VARCHAR(45) NULL ,
  `Weight` VARCHAR(45) NULL ,
  `PatientRecordcol` VARCHAR(45) NULL ,
  `Nurse_Staff_ID` INT NOT NULL ,
  `PatientInfo_PatientID` INT NOT NULL ,
  PRIMARY KEY (`RecordNo`) ,
  INDEX `fk_PatientRecord_Nurse1` (`Nurse_Staff_ID` ASC) ,
  INDEX `fk_PatientRecord_PatientInfo1` (`PatientInfo_PatientID` ASC) ,
  CONSTRAINT `fk_PatientRecord_Nurse1`
    FOREIGN KEY (`Nurse_Staff_ID` )
    REFERENCES `mydb`.`Nurse` (`Staff_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_PatientRecord_PatientInfo1`
    FOREIGN KEY (`PatientInfo_PatientID` )
    REFERENCES `mydb`.`PatientInfo` (`PatientID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Users`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Users` (
  `Username` VARCHAR(45) NOT NULL ,
  `passwd` VARCHAR(45) NOT NULL ,
  `UserGroup` ENUM('patient','nurse','physician') NOT NULL ,
  `ID` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`Username`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Logs`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Logs` (
  `Users_ID` VARCHAR(45) NOT NULL ,
  `Event` VARCHAR(50) NOT NULL ,
  `Time` DATETIME NOT NULL ,
  PRIMARY KEY (`Users_ID`, `Time`) ,
  CONSTRAINT `fk_Logs_Users1`
    FOREIGN KEY (`Users_ID` )
    REFERENCES `mydb`.`Users` (`Username` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`LabWork`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`LabWork` (
  `LabWorkID` INT NOT NULL ,
  `Physician_Staff_ID` INT NOT NULL ,
  `DataTime` DATETIME NOT NULL ,
  PRIMARY KEY (`LabWorkID`) ,
  INDEX `fk_LabWork_Physician1` (`Physician_Staff_ID` ASC) ,
  CONSTRAINT `fk_LabWork_Physician1`
    FOREIGN KEY (`Physician_Staff_ID` )
    REFERENCES `mydb`.`Physician` (`Staff_ID` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

