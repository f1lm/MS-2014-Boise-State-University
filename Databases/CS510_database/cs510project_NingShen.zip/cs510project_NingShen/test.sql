call logins('patient1' , 'passwd1');

call logFiles('patient1' , 'login');

call readLog('patient1' );

CALL createAccount('tester2','tester1','patient',2000);

call dropAccount('tester2');

CALL changePwd('patient1', 'passwd1', 'newpass');

call patientView(0001);

call CreatelivingWill(0001, 'live!');

call ModifyDecisionMaker(1, 'a','b','c','d');

call addInsurance(33333, '228-208-2828',323456789 , '2013-12-31','2014-12-31');

call ModifyInsurance(0001, 22222);

call PatientViewAppointment(0001);

call PhysicianViewAppointment(1001);

call createVisitingRecord('75.9','180lb','no details', '302', 0001);

call viewVisitingRecord(1);

call PhysicianViewPatient(1001, 0002);

call MakeAppointment(0002, 1002, '2023-12-31 01:02:23');

call transAppointment(1);

call MakePrescription('tester', 2, 0002, 02,03);

call preferPharmacy(0001, 03, 01);

call createWorksheet(1001, 'medicine', 'Monday 10am');

call modifyWorksheet(1001, 'medicine', 'Tuesday');
