use mydb;
-- for users to log in -------
DELIMITER $$
DROP PROCEDURE IF EXISTS `mydb`.`logins`;$$

DELIMITER // 
CREATE PROCEDURE logins(username varchar(45), pwd varchar(45)) 
BEGIN 
select Username, passwd, ID
from users
where username = users.Username and pwd = users.passwd ;
END // 
DELIMITER ; 




-- to log and login information to the log files -- 
DELIMITER $$
DROP PROCEDURE IF EXISTS `mydb`.`logFiles`;$$
DELIMITER // 
CREATE PROCEDURE logFiles(IN userid varchar(45),IN actions varchar(45)) 
BEGIN 
insert into Logs values(userid, actions, now());
END // 
DELIMITER ; 



-- search logs by user---
DELIMITER $$
DROP PROCEDURE IF EXISTS `mydb`.`readLog`;$$
DELIMITER // 
CREATE PROCEDURE readLog(IN userid varchar(45)) 
BEGIN 
select * from Logs where Logs.Users_ID = userid;
END // 
DELIMITER ; 


-- create a new account-- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`createAccount`//
create procedure createAccount( name varchar(45), pwd varchar(45), userGroup varchar(45), staffID INT)
begin
select * from Users where Users.Username = name;
set @account_exist:= found_rows();
if(@account_exist < 1) then 
insert into Users values(name, pwd, userGroup, staffID);
	else
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User already there';
end if;
select * from Users where Username = name;
end//
DELIMITER ;

-- drop a user account --
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`dropAccount`//
create procedure dropAccount( name varchar(45))
begin
delete  from Users where Username = name;
end//
DELIMITER ;


-- to change the password when the user offers the right old password--- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`changePwd`//
create procedure changePwd( name varchar(45), oldPwd varchar(45), newPwd varchar(45))
begin
select * from Users where Users.Username = name and Users.passwd = oldPwd;
set @account_auth:= found_rows();
if(@account_auth > 0) then 
update Users set passwd = newPwd 
where Users.Username = name;
else
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'change passwd failed';
end if;
end//
DELIMITER ;

-- patient view own information-- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`patientView`//
create procedure patientView( ID INT)
begin
select *
from PatientInfo
where PatientID = ID;
end//
DELIMITER ;

-- patient create living will --- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`CreatelivingWill`//
create procedure CreatelivingWill( ID INT, will varchar(45))
begin
insert into LivingWill (PatientInfo_PatientID, Living_Will) values(ID, will);
end//
DELIMITER ; 

-- patient modify decision maker in order -- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`ModifyDecisionMaker`//
create procedure ModifyDecisionMaker( ID INT, maker1 varchar(45), maker2 varchar(45),maker3 Varchar(45),maker4 Varchar(45))
begin
update LivingWill set DecisionMaker1 = maker1, 
DecisionMaker2 = maker2,
DecisionMaker3 = maker3, 
DecisionMaker4 = maker4
where
PatientInfo_PatientID = ID;
end//
DELIMITER ;

-- patient add a new insurance information to the database -- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`addInsurance`//
create procedure addInsurance(iID INT, phone varchar(30), ssn INT, start DATE, endDay DATE)
BEGIN
insert into Insurance values(iID, phone, ssn , start , endDay);
End//
DELIMITER ;


-- patient change his insurance ---- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`ModifyInsurance`//
create procedure ModifyInsurance(pID INT, iID INT)
BEGIN
select * from Insurance where Insurance_ID = iID;
set @count:= found_rows();
if(@count > 0) then 
update PatientInfo set Insurance_Insurance_ID = iID where PatientID = pID;
select * from PatientInfo where PatientID = pID;
else
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'no such insurance';
end if;
end //
DELIMITER ;


-- patient view his own appointment -- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`PatientViewAppointment`//
create procedure PatientViewAppointment(pID INT)
BEGIN
select * from FutureAppointment f where f.PatientInfo_PatientID = pID;
END//
DELIMITER ;

-- physician view his appointments -- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`PhysicianViewAppointment`//
create procedure PhysicianViewAppointment(pID INT)
BEGIN
select * from FutureAppointment f where f.Physician_Physician_ID = pID;
END//
DELIMITER ;


-- nurse reate visiting record -- 

DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`createVisitingRecord`//
create procedure createVisitingRecord(temp varchar(45), weight varchar(45), recordcol varchar(45), nurse int, patientid int)
BEGIN
insert into VisitRecord values(null, temp, weight, recordcol, nurse, patientid);
END//
DELIMITER ;

-- view the visiting records -- 

DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`viewVisitingRecord`//
create procedure viewVisitingRecord(recordid INT)
BEGIN
select * from VisitRecord where RecordNo = recordid;
END//
DELIMITER ;

-- physician can only view his own patients' information  -- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`PhysicianViewPatient`//
create procedure PhysicianViewPatient(phyID INT, patient INT)
BEGIN
select * from FutureAppointment f where f.Physician_Physician_ID = phyID;
set @count1:= found_rows();
select * from HistoryAppointment h where h.Physician_Physician_ID = phyID;
set @count2:= found_rows();
if(@count1 > 0 or @count2 > 0) then 
select * from PatientInfo where PatientID = patient;
else
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'no right to do so';
end if;
END//
DELIMITER ;


-- patient and physician make a appointment on a free time in the futrue-- 
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`MakeAppointment`//
create procedure MakeAppointment(patientID INT, physicianID INT, date_time DATETIME)
BEGIN
if(date_time > now()) then
select * from FutureAppointment where AppointmentDate = date_time;
set @counter:= found_rows();
if(@counter < 1) then
insert into FutureAppointment values(null, date_time, patientID, physicianID );
end if;
end if;
END//
DELIMITER ;


-- transfer appointment from future appointment to history appointment
DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`transAppointment`//
create procedure transAppointment(id INT)
BEGIN
insert into HistoryAppointment 
( select null,AppointmentDate, PatientInfo_PatientID, Physician_Physician_ID from FutureAppointment
where AppointmentID = id );
delete from FutureAppointment where AppointmentID = id;
END//
DELIMITER ;

-- create prescription --
 DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`MakePrescription`//
create procedure MakePrescription(medicine varchar(45), no INT, pID INT, phar1 INT, phar2 INT)
BEGIN
insert into prescription values(null, medicine, no, pID, phar1, phar2);
END//
DELIMITER ;


-- change prefered pharmacy by patient --

 DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`preferPharmacy`//
create procedure preferPharmacy(pID INT, phar1 INT, phar2 INT)
BEGIN
if(phar1 <> phar2) then
update prescription set Pharmacy_PharmacyNo1 = phar1 , Pharmacy_PharmacyNo2 = phar2
where PatientInfo_PatientID = pID;
else
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'pharmacy should be different';
end if;
END//
DELIMITER ;

-- assign worksheet --

 DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`createWorksheet`//
create procedure createWorksheet(pID INT, name varchar(45), time varchar(45))
BEGIN
select * from WorkSheet where Physician_Physician_ID= pID 
and Institution_InstitutionName = name
and Time = time;
set @count:= found_rows();
if(@count < 1) then
insert into WorkSheet values(pID, name, time);
else
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'time sheet already exist there';
end if;
END//
DELIMITER ;


-- modify worksheet --
 DELIMITER //
DROP PROCEDURE IF EXISTS `mydb`.`modifyWorksheet`//
create procedure modifyWorksheet(pID INT, name varchar(45), time varchar(45))
BEGIN
update WorkSheet set Institution_InstitutionName = name, Time = time
where Physician_Physician_ID= pID;
END//
DELIMITER ;
