call credit2(3173, 333250);

SET @customer:=-1;
call valuedCustomer(957367964, 699281889, @customer);
select @customer;