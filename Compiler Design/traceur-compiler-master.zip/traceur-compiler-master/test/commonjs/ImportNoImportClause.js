this.sideEffect = 1;
import './deps/side-effect';
assert.equal(2, this.sideEffect);
this.sideEffect = 1;
