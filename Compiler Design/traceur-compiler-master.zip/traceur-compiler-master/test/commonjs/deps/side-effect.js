this.sideEffect++;
