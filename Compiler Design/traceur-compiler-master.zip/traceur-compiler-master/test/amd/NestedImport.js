import {Bar} from './deps/bar';

assert.equal('Bar from bar.js', Bar);
