this.sideEffect = 1;
