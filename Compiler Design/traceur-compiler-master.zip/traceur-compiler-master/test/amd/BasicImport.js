import {Foo} from './deps/foo';

assert.equal('Foo from foo.js', Foo);
