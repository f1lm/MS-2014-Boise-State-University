function f() {
  if (typeof x1)
  x1;
}

function g() {
  typeof x2;
  x2;
}
