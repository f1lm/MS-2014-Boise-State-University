// Options: --classes=false
// Error: :4:1: Unexpected reserved word

class C {}
