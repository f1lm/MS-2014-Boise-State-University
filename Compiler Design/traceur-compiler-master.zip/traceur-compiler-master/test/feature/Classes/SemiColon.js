class SemiColon {
  ;
}