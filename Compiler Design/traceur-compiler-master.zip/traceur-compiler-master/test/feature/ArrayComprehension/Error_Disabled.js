// Options: --array-comprehension=false
// Error: :4:14: Unexpected token for

var array = [for (x of [0, 1, 2, 3, 4]) x];
