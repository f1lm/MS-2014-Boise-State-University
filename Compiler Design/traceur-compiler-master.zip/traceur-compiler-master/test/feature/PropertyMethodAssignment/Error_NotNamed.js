// Error: :5:12: notNamedField is not defined

var object = {
  "notNamedField"() {
    return notNamedField;
  }
};
