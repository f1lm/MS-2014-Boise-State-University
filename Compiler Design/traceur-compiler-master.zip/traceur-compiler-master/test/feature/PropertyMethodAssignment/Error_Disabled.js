// Options: --property-methods=false
// Error: :5:9: Unexpected token (

var object = {
  method() {
    return 42;
  }
};
