export async function asyncFunction() {
  return 1;
}

export default async function() {
  return 2;
};
