// Options: --generator-comprehension=false
// Error: :4:13: Unexpected token for

var iter = (for (x of [0, 1, 2, 3, 4]) x);
