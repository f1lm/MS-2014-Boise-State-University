// Options: --symbols

var s = new Set(['Banana', 'Orange', 'Apple', 'Mango', 'Apple', 'Apple']);
assert.equal(s.size, 4);
