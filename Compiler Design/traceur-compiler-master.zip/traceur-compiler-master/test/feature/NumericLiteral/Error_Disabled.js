// Options: --numeric-literals=false
// Error: :4:2: Semi-colon expected

0b11;
