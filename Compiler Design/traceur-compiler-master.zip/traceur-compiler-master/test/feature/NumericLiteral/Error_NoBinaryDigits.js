// Options: --numeric-literals
// Error: :4:3: Binary Integer Literal must contain at least one digit

0b;
