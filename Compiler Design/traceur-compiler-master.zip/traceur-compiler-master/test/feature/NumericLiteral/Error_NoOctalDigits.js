// Options: --numeric-literals
// Error: :4:3: Octal Integer Literal must contain at least one digit

0o;
