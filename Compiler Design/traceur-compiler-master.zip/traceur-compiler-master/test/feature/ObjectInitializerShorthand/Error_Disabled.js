// Options: --property-name-shorthand=false
// Error: :5:16: Unexpected token x

var x = 42;
var object = {x};
