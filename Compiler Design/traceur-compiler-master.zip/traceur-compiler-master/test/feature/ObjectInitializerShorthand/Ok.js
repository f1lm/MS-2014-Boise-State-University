var x = 42;
var y = 43;
var object = {x, y};

// ----------------------------------------------------------------------------

assert.equal(42, object.x);
assert.equal(43, object.y);
