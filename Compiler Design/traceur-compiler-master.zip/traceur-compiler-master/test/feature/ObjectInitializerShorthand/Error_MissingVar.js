// Error: missingVarObjectInitializerShorthand is not defined

var object = {missingVarObjectInitializerShorthand};
