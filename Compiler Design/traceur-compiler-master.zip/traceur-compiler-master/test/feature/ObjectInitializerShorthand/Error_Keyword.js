// Error: :3:18: Unexpected token var

var object = {var};
