this.sideEffect = 1;
import './resources/side-effect';
assert.equal(2, this.sideEffect);
this.sideEffect = 1;