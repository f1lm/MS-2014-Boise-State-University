import x from './resources/re-export-default';
assert.equal(x, 42);
