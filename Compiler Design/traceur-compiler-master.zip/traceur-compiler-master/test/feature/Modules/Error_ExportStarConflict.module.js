// Error: feature/Modules/resources/export-conflict.js:2:8: Duplicate export. 'a' was previously exported at feature/Modules/resources/export-conflict.js:1:12

import {a} from './resources/export-conflict';
