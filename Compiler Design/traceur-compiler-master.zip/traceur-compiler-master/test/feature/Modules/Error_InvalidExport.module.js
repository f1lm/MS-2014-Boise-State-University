// Error: :3:9: 'c' is not exported by 'feature/Modules/resources/a'

export {c} from './resources/a';
