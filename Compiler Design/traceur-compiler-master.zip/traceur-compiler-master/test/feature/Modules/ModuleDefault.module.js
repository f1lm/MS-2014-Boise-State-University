import * as m from './resources/default';

assert.equal(m.default, 42);
