import {TestClass} from './resources/TestClass';
assert.equal(TestClass.method(), 42);
