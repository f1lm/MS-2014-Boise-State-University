var global = this;

import * as m from './resources/f';
assert.equal(global, m.f());
