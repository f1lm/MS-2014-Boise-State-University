import * as m from './resources/m3';
assert.equal(m.x, 'z');
