// Error: :3:9: Unexpected token if

export {if as x};
