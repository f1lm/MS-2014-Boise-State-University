// Error: :3:10: Unexpected token from

import * from './resources/m';
assert.equal(3, a + b);
