var z = 'z';
export {z as var};
