import {var as x} from './m2';
export {x};
