export default class {
  n() {
    return 'n';
  }
}
