export var i = 0;
export function inc() {
  i++;
}
