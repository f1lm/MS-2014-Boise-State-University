export var f = () => this;
