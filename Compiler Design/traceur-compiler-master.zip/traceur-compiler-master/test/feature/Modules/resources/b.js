import * as c from './c';
