export class TestClass {
  static method() {
    return 42;
  }
}
