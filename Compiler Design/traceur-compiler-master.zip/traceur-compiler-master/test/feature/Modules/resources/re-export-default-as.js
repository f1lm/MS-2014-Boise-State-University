export {default as x} from './default';
