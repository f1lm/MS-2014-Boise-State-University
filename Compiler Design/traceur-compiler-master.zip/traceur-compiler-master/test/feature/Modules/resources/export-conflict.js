export var a = 'a';
export * from './a';  // also exports a
