import {counterclockwise} from '../ImportCircular.module';
export function clockwise() {
  return 'The circle is complete';
}
