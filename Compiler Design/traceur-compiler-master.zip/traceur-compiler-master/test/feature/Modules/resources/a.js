export var a = 'A';
