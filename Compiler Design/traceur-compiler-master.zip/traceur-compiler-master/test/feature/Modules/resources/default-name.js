var p = 4;
export {p as default};
