import {x} from './resources/re-export-default-as';
assert.equal(x, 42);
