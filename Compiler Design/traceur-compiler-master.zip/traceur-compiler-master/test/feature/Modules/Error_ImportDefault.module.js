// Error: feature/Modules/Error_ImportDefault.module.js:3:8: 'default' is not exported by 'feature/Modules/resources/a'

import error from './resources/a';
