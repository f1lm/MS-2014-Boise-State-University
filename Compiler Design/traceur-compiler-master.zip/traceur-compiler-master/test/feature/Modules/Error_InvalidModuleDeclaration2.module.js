// Error: 3:38: Unexpected token .

import * as b from './resources/a.js'.c;