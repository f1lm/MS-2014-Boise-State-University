assert.equal(__moduleName, 'feature/Modules/ModuleName.module');
