// Error: :3:9: 'c' is not exported by 'feature/Modules/resources/a'

export {c as d} from './resources/a';
