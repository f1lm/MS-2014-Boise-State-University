import * as o from './resources/o';

assert.equal(1, o.a);
assert.equal(2, o.b);
assert.equal(3, o.c);
assert.equal(4, o.d);
