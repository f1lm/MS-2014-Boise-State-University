// Error: :9:1: innerX is not defined

try {
  throw [0];
} catch ([innerX]) {

}

innerX;
