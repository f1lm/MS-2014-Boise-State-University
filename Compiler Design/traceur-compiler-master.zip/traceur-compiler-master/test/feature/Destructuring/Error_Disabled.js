// Options: --destructuring=false
// Error: 4:5: Unexpected token [

var [x, y] = [0, 1];
