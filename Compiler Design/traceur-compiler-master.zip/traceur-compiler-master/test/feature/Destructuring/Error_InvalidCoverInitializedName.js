// Error: :3:5: Unexpected token =

({x = 42});
