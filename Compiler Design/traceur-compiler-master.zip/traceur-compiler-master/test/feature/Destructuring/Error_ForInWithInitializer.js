// Error: :3:19: Unexpected token in

for (var {k} = {} in {}) {
}
