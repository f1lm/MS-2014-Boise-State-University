// Error: :3:16: Unexpected token ,

var f = ([...xs, ys]) => xs;
