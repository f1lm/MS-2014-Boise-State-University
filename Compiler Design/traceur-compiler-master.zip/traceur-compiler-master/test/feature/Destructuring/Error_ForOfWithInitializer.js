// Error: :3:19: Unexpected token of

for (var {k} = {} of []) {
}
