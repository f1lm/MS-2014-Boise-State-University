function UnannotatedUntypedParams(x, y) {}

assert(!UnannotatedUntypedParams.annotations);
assert(!UnannotatedUntypedParams.parameters);
