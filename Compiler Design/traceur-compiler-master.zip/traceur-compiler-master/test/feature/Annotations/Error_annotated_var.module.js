// Options: --annotations
// Error: :8:1: Unsupported annotated expression
import {Anno} from './resources/setup';

@Anno
var test = 1;

