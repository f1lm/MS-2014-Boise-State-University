import {Anno} from './setup';

@Anno
export default function (@Anno x) {};
