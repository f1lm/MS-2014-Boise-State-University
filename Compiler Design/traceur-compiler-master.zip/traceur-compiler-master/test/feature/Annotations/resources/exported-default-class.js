import {Anno} from './setup';

@Anno
export default class {
  @Anno
  annotatedMethod() {}
};
