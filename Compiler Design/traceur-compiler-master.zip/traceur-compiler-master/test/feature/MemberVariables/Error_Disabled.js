// Error: :4:4: Unexpected token :

class C {
  x: number;
}
