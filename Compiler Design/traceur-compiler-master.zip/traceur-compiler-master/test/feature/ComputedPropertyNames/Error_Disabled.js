// Options: --computed-property-names=false
// Error: :5:3: Unexpected token [

var object = {
  [1]: 2
};
