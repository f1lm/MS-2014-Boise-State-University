// Error: :4:9: Semi-colon expected
// Error: :4:9: Unexpected token =>

(x) + y => y;
