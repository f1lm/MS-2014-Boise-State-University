// Error: :4:11: Semi-colon expected
// Error: :4:11: Unexpected token =>

(x) + (y) => y;
