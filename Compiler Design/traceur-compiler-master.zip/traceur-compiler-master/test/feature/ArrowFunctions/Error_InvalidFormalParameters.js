// Error: :3:15: Unexpected token +

var f = (a, b + 5) => a + b;
