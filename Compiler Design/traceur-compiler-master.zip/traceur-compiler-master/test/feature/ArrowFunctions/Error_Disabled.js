// Options: --arrow-functions=false
// Error: :4:21: Unexpected token >

var identity = (x) => x;
