var identity = (identityParam) => identityParam;
assert.equal(1234, identity(1234));
