// Options: --arrow-functions
// Error: :3:35: missingIdentifier is not defined
var identity = (identityParam) => missingIdentifier;
