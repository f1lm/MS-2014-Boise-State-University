// Error: :3:18: Unexpected token =

var f = ({x = {y = 1}) => 2;