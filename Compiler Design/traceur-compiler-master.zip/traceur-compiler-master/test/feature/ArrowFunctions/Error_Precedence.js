// Error: :3:26: Semi-colon expected

var identity = (x) => {x}.bind({});
