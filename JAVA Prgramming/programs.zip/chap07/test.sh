

echo "java CmdLineArgs abc 123 12.4"
java CmdLineArgs abc 123 12.4
echo "java CmdLineArgs abc 1000 12.4"
java CmdLineArgs abc 1000 12.4
echo "java CmdLineArgs abc 2000 12.4"
java CmdLineArgs abc 2000 12.4
echo "java CmdLineArgs abc 400000000 12.4898"
java CmdLineArgs abc 400000000 12.4898
