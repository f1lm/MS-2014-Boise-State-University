
/**
 * Prompt for details about marbles the user is adding to
 * their collection. After each marble is added, report on
 * the collection.
 * 
 * @author mvail
 */
public class SphereBag {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Sphere s1 = new Sphere(1.0, 2.0);
		
		System.out.println(s1);
		
		s1.setMass(1.0);
		
		System.out.println(s1);

	}

}
