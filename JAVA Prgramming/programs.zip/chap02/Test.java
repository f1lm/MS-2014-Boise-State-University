

public class Test {

	public static void main(String[] args)
	{
		System.out.println("\n Incorrect: \t(4/3) * Math.PI \t = \t " + (4/3) * Math.PI);
		System.out.println("\n Incorrect: \t 4/3 * Math.PI  \t = \t " + 4/3 * Math.PI);
		System.out.println("\n Correct: \t Math.PI * 4/3  \t = \t " + Math.PI * 4/3);
		System.out.println("\n Correct: \t 4.0/3 * Math.PI  \t = \t " + 4.0/3 * Math.PI);
		System.out.println("\n Correct: \t (double)4/3 * Math.PI \t = \t " + (double)4/3 * Math.PI);
	}

}
