
 
//***************************************************************************
//  PrimitiveTypes.java       Author: Amit
//
//  Demonstrates  how to fin minimum/maximum values for some primitive types
//***************************************************************************

public class PrimitiveTypes
{
   public static void main (String[] args)
   {
      System.out.println (Integer.MAX_VALUE);
      System.out.println (Integer.MIN_VALUE);
   }
}
