
public class StuckDance
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		System.out.println("Stuck Dance" + "\n");
		System.out.println("i am stuck");
		System.out.println("i am stuck");
		System.out.println("i am stuck");
		System.out.println("i am stuck" + "\n");
		
		System.out.println("in the snow");
		System.out.println("i don't know");
		System.out.println("in the muck ");
		System.out.println("with no luck ");
		System.out.println("look at the coot ");
		System.out.println("having a hoot ");
		System.out.println("still i am stuck" + "\n");

		System.out.println("wheels slipping ");
		System.out.println("i am falling ");
		System.out.println("face in mud ");
		System.out.println("full of crud ");
		System.out.println("oh i am stuck" + "\n");

		System.out.println("the waves break ");
		System.out.println("with such grace ");
		System.out.println("near my face ");
		System.out.println("the granite rock ");
		System.out.println("near the flock ");
		System.out.println("i take stock ");
		System.out.println("sand tastes yuck ");
		System.out.println("i come unstuck" + "\n");

		System.out.println("an osprey dives ");
		System.out.println("my foot gives ");
		System.out.println("as i leap ");
		System.out.println("over the creek ");
		System.out.println("but i freak" + "\n");

		System.out.println("a big thud ");
		System.out.println("and i tumble ");
		System.out.println("sky a jumble ");
		System.out.println("while i mumble ");
		System.out.println("lake in sky ");
		System.out.println("hills so high ");
		System.out.println("my eyes smart ");
		System.out.println("a pounding heart ");
		System.out.println("i am so stuck." + "\n");
		
		// \u00A9 is hexadecimal code for the copyright symbol
		System.out.println("\n" + "\u00a9" + "  Amit Jain");
	}

}
