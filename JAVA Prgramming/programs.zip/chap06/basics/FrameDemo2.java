
/**
 	Create a simple frame and show it.
	@author amit
 */

public class FrameDemo2
{
	public static void main (String[] args)
	{
		SimpleFrame2 frame = new SimpleFrame2();
		frame.setVisible(true);
	}
}
