
/**
 	Create a simple frame and show it.
	@author amit
 */

public class FrameDemo1
{
	public static void main (String[] args)
	{
		SimpleFrame1 frame = new SimpleFrame1();
		frame.setVisible(true);
	}
}
