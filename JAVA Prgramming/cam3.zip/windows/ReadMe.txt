The sources of the windows APIs. The executable may be downloaded at http://www.must.de/camexe.html.
