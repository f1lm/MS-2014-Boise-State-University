package selftest;

import java.awt.Component;
import java.awt.Container;
import java.awt.Window;

import javax.swing.JMenu;

public class ComponentFinder {
	
	public static Component findComponent(Component component, String name) {
		return findComponent(component, null, name);
	}

	// Within the given container, find the GUI component of a given type (componentType) and name (componentName)
	// If componentType is null, return the first component with the given name.  

	public static Component findComponent(Component container, Object componentType, String componentName) {
//		System.out.println("Class: " + parent.getClass() +
//		    " Name: " + parent.getName());
		if (componentName.equals(container.getName())) {
			if (componentType ==null || container.getClass()== componentType.getClass()) {
//System.out.println("Found " + container.getClass() +" object named \"" + componentName+"\"."); 
				return container; 
			}
		}
		
		if (container instanceof Container) {
			// search for menu items and other components 
			Component[] children = (container instanceof JMenu)?
		          ((JMenu)container).getMenuComponents():
		          ((Container)container).getComponents();		   
		    for (int i = 0; i < children.length; ++i) {
		    	Component child = findComponent(children[i], componentType, componentName);
		        if (child != null) { 
		        	return child; 
		        }
            }
		    // search for components in owned windows 
		    if (container instanceof Window) {
		    	Component[] ownedWindows = ((Window)container).getOwnedWindows(); 		   
			    for (int i = 0; i < ownedWindows.length; ++i) {
			    	Component child = findComponent(ownedWindows[i], componentType, componentName);
			        if (child != null) { 
			        	return child; 
			        }
	            }
		    }
	    }
		return null;
	}

	public static void printChildren(Component parent) {
		// Debug line
		System.out.println("GUI Component: Class: " + parent.getClass() +
		    " Name: " + parent.getName());

		if (parent!=null && parent instanceof Container) {
			Component[] children = (parent instanceof JMenu)?
		          ((JMenu)parent).getMenuComponents():
		          ((Container)parent).getComponents();		   
		    for (int i = 0; i < children.length; ++i)
		    	if (children[i]!=null)
		    		printChildren(children[i]);
	    }
	}
}
