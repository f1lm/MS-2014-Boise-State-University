import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.FileReader;

/**
   This program computes square roots of inputs supplied
   through System.in
*/
public class RootApproximatorHarness2
{

static final String fileName = "test.in";

   public static void main(String[] args)
      throws IOException
   {
      BufferedReader console
//         = new BufferedReader(new InputStreamReader(System.in));
         = new BufferedReader(new FileReader(fileName));
      boolean done = false;
      while (!done)
      {
         String input = console.readLine();
         if (input == null) done = true;
         else
         {
            double x = Double.parseDouble(input);
            RootApproximator r = new RootApproximator(x);
            double y = r.getRoot();

            System.out.println("square root of " + x
               + " = " + y);
         }
      }
   }
}
