import java.util.Hashtable;


public class AccountManager {
	
    private Hashtable<String, String> userAccount;
    
    public AccountManager() {
        userAccount = new Hashtable<String, String>();

        userAccount.put("user", "pass");
        userAccount.put("NDSU", "123456");
        userAccount.put("junit", "junit");
        userAccount.put("jfcunit", "jfcunit");
    }
    
    public boolean verify(String userName, String password) {
       if(userName == null || password ==null)    
    	   return false;   
       String storedPassword = userAccount.get(userName);
       return storedPassword != null && storedPassword.equals(password);
    }
}
