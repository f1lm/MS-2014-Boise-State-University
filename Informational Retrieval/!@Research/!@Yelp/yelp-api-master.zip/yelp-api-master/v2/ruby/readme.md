# Yelp + Ruby

To use the Yelp API with Ruby, we have our official Ruby gem that makes integration easy. Check out the [readme](https://github.com/yelp/yelp-ruby) for more information and the [blog post](http://engineeringblog.yelp.com/2014/04/more-yelp-in-your-ruby.html) with a few examples.

Here we have a sample Rails application that shows you how you can integrate the Yelp API into your Rails app. It contains a detailed readme on everything you should need to get it up and running.