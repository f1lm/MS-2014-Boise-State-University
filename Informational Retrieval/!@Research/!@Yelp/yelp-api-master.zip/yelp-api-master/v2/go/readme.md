# Go + Yelp

If you're using the Yelp API with Go, you should check out [go-yelp](https://github.com/JustinBeckwith/go-yelp), written by [JustinBeckwith](https://github.com/JustinBeckwith)
