﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YelpSharp.Data.Options
{
    public abstract class LocationOptionBase : BaseOptions
    {
    }
}
