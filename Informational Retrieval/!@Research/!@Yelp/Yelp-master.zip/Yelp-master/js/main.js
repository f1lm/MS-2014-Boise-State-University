(function(window, document, undefined) {

  /* MainView handles all the logic. */
  $(document).ready(function() {
    MainView.render($(document.body));
  });

})(this, this.document);
