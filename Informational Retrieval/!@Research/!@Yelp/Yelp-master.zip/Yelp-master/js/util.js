(function(window, document, undefined) {
  var Util = {};

  // TODO

  window.Util = Util;
})(this, this.document);
