﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheCircularStack
{
    public class CircluarStack
    {
        public int[] Space = new int[5];

        public int Root =-1, Peak = -1, Deep = 0;

        public string Message = string.Empty;



        public void PrintMessage(string message)
        {
            switch(message)
            {
                case  "Full":
                    Message = "Stack Full";
                    break;
                case "FrontEmpty":
                    Message = "Stack Empty At Front";
                    break;
                case "BackEmpty":
                    Message = "Stack Empty At Back";
                    break;
                case "Empty":
                    Message = "Oops! Stack Empty";
                    break;

            }
        }

        /// <summary>
        /// Push Item in Front
        /// </summary>
        /// <param name="item"></param>
        public void PushFront(int item)
        {
            Message = string.Empty;

            if (Root < Space.Length && Deep < Space.Length)
            {
                for (int i = Deep - 1; i >= 0; i--)
                {
                    Space[i + 1] = Space[i];
                }
                Space[0] = item;
                Root++;
                Deep++;
            }
            else
            {
                PrintMessage("Full");
            }

        }   

        /// <summary>
        /// Push Item in Back
        /// </summary>
        /// <param name="item"></param>
        public void PushBack(int item)
        {
            Message = string.Empty;

            if(Root == Deep)
            {
                Deep++;
            }

            if (Root < Space.Length && Deep < Space.Length)
            {
                Space[Deep] = item;
                Deep++;
            }
            else
            {
                PrintMessage("Full");
            }

        }

        /// <summary>
        /// Pop Item In Front
        /// </summary>
        /// <returns></returns>
        public int PopFront()
        {
            Message = string.Empty;

            if ( Deep > -1 &&  Root != -1)
            {
                var popedItem = Space[0];
                for (int i = 0; i < Deep-1; i++)
                {
                    Space[i] = Space[i + 1];
                }

                Space[Deep-1] = 0;

                Root--;
                Deep--;

                return popedItem;
            }
            else
            {
                if (Deep - 1 != Root)
                {
                    PrintMessage("FrontEmpty");
                }
                else
                {
                    PrintMessage("Empty");
                }

                return -1;
            }
        }

        /// <summary>
        /// Pop Item in Back
        /// </summary>
        /// <returns></returns>
        public int PopBack()
        {
            Message = string.Empty;

            if (Deep -1 < Space.Length &&  Deep -1 > Root)
            {
                var popedItem = Space[Deep-1];
                Space[Deep -1] = 0;
                Deep--;
                return popedItem;
            }
            else
            {
                if (Root == -1)
                {
                    PrintMessage("Empty");
                }
                else
                {
                    PrintMessage("BackEmpty");
                }
            
                return -1;
            }
        }


  

    }
}
