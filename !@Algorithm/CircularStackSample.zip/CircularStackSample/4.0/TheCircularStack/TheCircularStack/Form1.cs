﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheCircularStack
{
    public partial class Form1 : Form
    {

        CircluarStack circularStack = new CircluarStack();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            circularStack.PushFront(Convert.ToInt16(textBox1.Text));
            RefreshStack();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            circularStack.PushBack(Convert.ToInt16(textBox1.Text));
            RefreshStack();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.label7.Text = circularStack.PopFront().ToString();
            RefreshStack();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.label7.Text = circularStack.PopBack().ToString();
            RefreshStack();
        }

        public void RefreshStack()
        {
            try
            {
                this.label6.Text = this.label5.Text = this.label4.Text = this.label3.Text = this.label2.Text = this.label1.Text = string.Empty;
                this.label6.Text = circularStack.Message;
                this.label1.Text = circularStack.Space[0] != 0 ? circularStack.Space[0].ToString() : String.Empty;
                this.label2.Text = circularStack.Space[1] != 0 ? circularStack.Space[1].ToString() : String.Empty;
                this.label3.Text = circularStack.Space[2] != 0 ? circularStack.Space[2].ToString() : String.Empty;
                this.label4.Text = circularStack.Space[3] != 0 ? circularStack.Space[3].ToString() : String.Empty;
                this.label5.Text = circularStack.Space[4] != 0 ? circularStack.Space[4].ToString() : String.Empty;
            }
            catch(Exception e)
            {

            }

           
        }

    }
}
