using System;

namespace StackVsHeap
{
     public class MyInt
     {
          public int MyValue;
     }

     class Class1
     {
          
          [STAThread]
          static void Main(string[] args)
          {
               Class1 cls = new Class1();

               Console.WriteLine(cls.ReturnValue());
               Console.WriteLine(cls.ReturnValue2());
               Console.ReadLine();     
          }

          public int ReturnValue()
          {
               int x = new int();
			    x = 3;

               int y = new int();
                y = x;
                 
               y = 4;

               return x;
          }

          public int ReturnValue2()
          {
               MyInt x = new MyInt();
               x.MyValue = 3;

               MyInt y = new MyInt();
               y = x;
                 
               y.MyValue = 4;

               return x.MyValue;
          }
     }
}
