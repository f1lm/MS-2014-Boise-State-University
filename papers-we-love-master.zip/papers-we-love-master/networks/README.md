* [Bimodal Multicast](http://www.csl.mtu.edu/cs6461/www/Reading/Birman99.pdf)
