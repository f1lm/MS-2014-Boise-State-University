* :scroll: [A Mathematical Theory of Communication](http://cm.bell-labs.com/cm/ms/what/shannonday/shannon1948.pdf)

* [Differential Privacy](http://www.msr-waypoint.com/pubs/64346/dwork.pdf)
  - How do we quantify the exposure an individual faces from being
    included in a statistical dataset?  How do we anonymize aggregated
    data in a way that has formal guarantees?
