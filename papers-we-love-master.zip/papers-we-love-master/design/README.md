* [Traits: A Mechanism for Fine-Grained Reuse](http://scg.unibe.ch/archive/papers/Duca06bTOPLASTraits.pdf)
