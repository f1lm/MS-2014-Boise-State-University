* [Asynchronous Functional Reactive Programming for GUIs](http://people.seas.harvard.edu/~chong/pubs/pldi13-elm.pdf)

* [Push-Pull Functional Reactive Programming](http://conal.net/papers/push-pull-frp/push-pull-frp.pdf)

* [Wormholes: Introducing Effects to FRP](http://haskell.cs.yale.edu/wp-content/uploads/2012/08/Winograd-Cort-Wormholes.pdf)
