# Stringology

## External Papers

* [A Taxonomy of Suffix Array Construction Algorithms](http://www.cas.mcmaster.ca/~bill/best/algorithms/07Taxonomy.pdf)
    - A great introduction to
      [suffix arrays](http://en.wikipedia.org/wiki/Suffix_array), but
      also a survey paper that is more than the sum of its citations,
      clarifying the presentation of all the algorithms with a
      unifying framework.
