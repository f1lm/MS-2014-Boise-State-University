# Testing

## QuickCheck

[QuickCheck: A Lightweight Tool for Random Testing of Haskell Programs](http://www.cs.tufts.edu/~nr/cs257/archive/john-hughes/quick.pdf)

[QuickCheck Testing for Fun and Profit](http://people.inf.elte.hu/center/fulltext.pdf)

Property-Based Testing, best explained in John Hughes own talk at [ClojureWest 2014](https://www.youtube.com/watch?v=zi0rHwfiX1Q&list=PLZdCLR02grLp__wRg5OTavVj4wefg69hM).
