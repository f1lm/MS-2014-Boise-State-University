* [D-Expressions: Lisp Power, Dylan Style](http://people.csail.mit.edu/jrb/Projects/dexprs.pdf)
* [Fortifying Macros](http://www.ccs.neu.edu/racket/pubs/icfp10-cf.pdf)
