# Program Verification

* [Coq: The world’s best macro assembler?](https://research.microsoft.com/en-us/um/people/nick/coqasm.pdf)
