# Speech Recognition

## External Papers

[A tutorial on hidden Markov models and selected applications in speech recognition](http://people.sabanciuniv.edu/~berrin/cs512/reading/rabiner-tutorial-on-hmm.pdf)

[Weighted Finite-State Transducers in Speech Recognition](http://www.cs.nyu.edu/~mohri/pub/csl01.pdf)

[Decoding speech in the presence of other sources](http://www.ee.columbia.edu/~dpwe/pubs/BarkCE05-sfd-spcomm.pdf)