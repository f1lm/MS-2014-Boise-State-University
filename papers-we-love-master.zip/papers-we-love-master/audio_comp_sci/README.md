## Audio-related Computer Science

[An ethnographic and technological study of breakbeats in Hardcore, Jungle, and Drum & Bass](https://github.com/papers-we-love/papers-we-love/blob/master/audio_comp_sci/an-ethnographic-and-technological-study-of-breakbeats.pdf) by Jason A. Hockman 

[An Industrial-Strength Audio Search Algorithm](https://github.com/papers-we-love/papers-we-love/blob/master/audio_comp_sci/shazam-audio-search-algorithm.pdf) by Avery Li-Chun Wang
