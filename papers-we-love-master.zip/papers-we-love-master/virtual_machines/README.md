* [One VM to Rule Them All](https://www.cs.purdue.edu/homes/gkrichar/papers/onward2013-wuerthinger-truffle.pdf)
    - This is an exciting VM implementation that incorporates AST node rewriting and an optimizing compiler. It enables the implementation of, and excellent performance for, a wide range of languages.
