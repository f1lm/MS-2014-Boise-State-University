# Physics

* :scroll: [On the attraction of two perfectly conducting plates](on-the-attraction-of-two-perfectly-conducting-plates.pdf)
