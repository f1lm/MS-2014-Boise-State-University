# Computer Architecture

* [Piranha: A Scalable Architecture Based on Single-Chip Multiprocessing](http://barroso.org/publications/isca00.pdf)
