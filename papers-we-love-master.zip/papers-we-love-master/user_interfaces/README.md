# User Interfaces

[Squeak: a Language for Communicating with Mice](http://ordiecole.com/squeak/cardelli_squeak1985.pdf)
