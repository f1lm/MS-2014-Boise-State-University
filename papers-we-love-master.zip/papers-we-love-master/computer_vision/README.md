* [Coupled 3D Reconstruction of Sparse Facial Hair and Skin](http://www.disneyresearch.com/project/coupled-3d-reconstruction-of-sparse-facial-hair-and-skin/)

* [High-Quality Single-Shot Capture of Facial Geometry](http://www.disneyresearch.com/project/high-quality-single-shot-capture-of-facial-geometry/)
