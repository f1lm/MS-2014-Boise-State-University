* [Xen and the Art of Virtualization](http://www.cl.cam.ac.uk/research/srg/netos/papers/2003-xensosp.pdf)

* [The operating system: should there be one?](http://plosworkshop.org/2013/preprint/kell.pdf)
