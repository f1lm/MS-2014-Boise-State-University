package dto;

public enum Status {
	PENDING, CONFIRMED, YOU
}
