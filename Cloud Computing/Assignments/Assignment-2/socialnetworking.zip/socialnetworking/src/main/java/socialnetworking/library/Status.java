package socialnetworking.library;

public enum Status {
	PENDING, CONFIRMED, YOU
}
