package socialnetworking.library;

public class LikesObjects extends MessageObjects {

	private int _like_id;
	private int _uid;

	public int get_like_id() {
		return _like_id;
	}

	public void set_like_id(int _like_id) {
		this._like_id = _like_id;
	}

	public int get_uid() {
		return _uid;
	}

	public void set_uid(int _uid) {
		this._uid = _uid;
	}

}
