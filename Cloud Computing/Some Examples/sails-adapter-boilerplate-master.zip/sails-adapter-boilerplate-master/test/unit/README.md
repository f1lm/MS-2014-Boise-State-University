# Adapter Unit Tests

`waterline-adapter-tests` provide a good layer of basic coverage for adapters.  Since usage is standarized, tests are highly reusable.

That said, if there is adapter-specific logic that you feel should be unit tested, this is the place to do it.
