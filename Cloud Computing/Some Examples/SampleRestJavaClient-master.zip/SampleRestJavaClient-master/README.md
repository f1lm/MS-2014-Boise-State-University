SampleRestJavaClient
====================

This sample code demonstrate how to use Nutanix JDK to connect to PRISM and execute basic instructions
