package webService;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import model.ProjectManager;
import transformer.FeedTransformer;
import dto.FeedObjects;


@Path("/WebService")
public class FeedService {
	
	@GET
	@Path("/GetFeeds")
	@Produces("application/json")
	public String messageFeed(@QueryParam("userId") String User_Id)
	{
		String feeds  = null;
		try 
		{
			ArrayList<FeedObjects> feedData = null;
			ProjectManager projectManager= new ProjectManager();
			feedData = projectManager.GetFeeds(User_Id);
			feeds=FeedTransformer.UserFeed(feedData);
			

		} catch (Exception e)
		{
			System.out.println("error");
		}
		return feeds;
	}

}
