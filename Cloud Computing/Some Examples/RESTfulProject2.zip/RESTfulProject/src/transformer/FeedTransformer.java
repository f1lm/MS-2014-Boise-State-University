package transformer;

import java.util.ArrayList;

import com.google.gson.Gson;

import dto.FeedObjects;

public class FeedTransformer 
{
  public static String UserFeed(ArrayList<FeedObjects> feedData)
	{
	String feeds  = null;
	Gson gson = new Gson();
	feeds = gson.toJson(feedData);
	return feeds;
	}
}
