Connection-viaREST
==================

PowerShell Connection to Nutanix using Invoke-RestMethod
