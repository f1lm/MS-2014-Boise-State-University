app_option(
  '--detailed-exitcodes', :flag,
  "Provide transaction information via exit codes, see puppet-agent(8)\n" +
    "for full details.",
  :default => false
)
